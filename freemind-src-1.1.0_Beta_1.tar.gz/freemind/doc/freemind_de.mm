<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#993300" CREATED="1124560950701" ID="Freemind_Link_1694418332" MODIFIED="1381605745737">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body width="">
    <p align="center">
      FreeMind<br/><small>- Freie Mind Mapping Software -</small>&#xa0;
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="Dialog" SIZE="18"/>
<node CREATED="1124560950701" ID="Freemind_Link_296874513" LINK="http://freemind.sourceforge.net" MODIFIED="1131994301515" POSITION="left" TEXT="Zur Homepage von FreeMind">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1091417446" MODIFIED="1131983900430" POSITION="left" TEXT="Tabelle der Tastaturk&#xfc;rzel">
<node CREATED="1124560950701" ID="Freemind_Link_814283472" MODIFIED="1134670510629" TEXT="Tastaturk&#xfc;rzel in Freemind 0.8.0 (Voreinstellung)&#xa;&#xa;&#xa;Datei:&#xa;Neu                 - Strg-N&#xa;&#xd6;ffnen...           - Strg-O&#xa;Speichern           - Strg-S&#xa;Speichern unter...  - Strg+Umschalt-S&#xa;Schlie&#xdf;en           - Strg-W&#xa;Drucken             - Strg-P&#xa;Beenden             - Strg-Q&#xa;&#xa;Datei-&gt;Export:&#xa;Zweig...            - Alt-A    (Zweig ab aktuellem Knoten als neue MM-Datei) &#xa;Als HTML            - Strg-E   (komplette MindMap als neue HTML-Datei)&#xa;HTML des Zweiges    - Strg-H   (Zweig ab aktuellem Knoten als neue HTML-Datei)&#xa;&#xa;Datei-&gt;Zuletzt ge&#xf6;ffnete Dateien:&#xa;&lt;Pfadname_der_zuletzt_ge&#xf6;ffneten_Datei&gt;  - Strg+Umschalt-W &#x9;&#xa;&#xa;&#xa;Bearbeiten:&#xa;R&#xfc;ckg&#xe4;ngig                       - Strg-Z&#xa;Wiederherstellen                 - Strg-Y&#xa;Alles markieren                  - Strg-A&#xa;Zweig markieren                  - Strg+Umschalt-A&#xa;Ausschneiden                     - Strg-X&#xa;Kopieren                         - Strg-C&#xa;Einfach kopieren                 - Strg+Umschalt-C&#xa;Einf&#xfc;gen                         - Strg-V&#xa;Formatierung kopieren            - Alt-C&#xa;Formatierung einf&#xfc;gen            - Alt-V&#xa;Knoten bearbeiten                - F2&#xa;Knoten in einem separaten Editor bearbeiten...  - Alt-Eingabe&#xa;Knoten l&#xf6;schen                   - Entf&#xa;Suchen                           - Strg-F&#xa;Weitersuchen                     - Strg-G&#xa;Knoten bearbeiten                - F2&#xa;Knoten nach oben schieben        - Strg-Oben&#xa;Knoten nach unten schieben       - Strg-Unten&#xa;Knoten falten/entfalten          - Leertaste&#xa;&#xa;&#xa;Ansicht:&#xa;Zoom +              - Alt-Unten&#xa;Zoom -              - Alt-Oben&#xa;&#xa;&#xa;Einf&#xfc;gen:&#xa;Neuer Unterknoten                - Einfg&#xa;Neuer Geschwisterknoten danach   - Eingabe&#xa;Neuer Geschwisterknoten davor    - Umschalt-Eingabe&#xa;Einr&#xfc;ckung erh&#xf6;hen               - Umschalt-Einfg&#xa;Bild (Dateiauswahl)...           - Alt-K&#xa;Hyperlink (Dateiauswahl)...      - Strg+Umschalt-K&#xa;Hyperlink (Textfeld)...          - Strg-K&#xa;Graphische Verbindung erzeugen   - Strg-L&#xa;Lokalen Hyperlink hinzuf&#xfc;gen     - Alt-L&#xa;Wolke                            - Strg+Umschalt-B&#xa;&#xa;Einf&#xfc;gen-&gt;Icons:&#xa;Icon w&#xe4;hlen                      - Alt-I&#xa;&#xa;&#xa;Format:&#xa;Knotenschrift vergr&#xf6;&#xdf;ern         - Strg-+&#xa;Knotenschrift verkleinern        - Strg--&#xa;Kursiv                           - Strg-I&#xa;Fett                             - Strg-B&#xa;Knotenfarbe &#xe4;ndern...            - Alt-F&#xa;Knotenfarbe aufhellen            - Alt-B&#xa;Kantenfarbe...                   - Alt-E&#xa;&#xa;Format-&gt;Stile:&#xa;Default                 - F1               (Vorgabe)&#xa;Normal                  - Strg+Umschalt-N  (Normal)&#xa;OK                      - F3               (OK)&#xa;Needs action            - F4               (Braucht Bearbeitung)&#xa;Hot                     - F5               (Hei&#xdf;)&#xa;Detail                  - F6               (Einzelheit)&#xa;Folder                  - F7               (Ordner)&#xa;Topic                   - F8               (Thema)&#xa;Larger Topic            - F9               (Umfangreicheres Thema)&#xa;Waiting Topic           - Strg-F1          (Wartendes Thema)     &#xa;Object / Keyword        - Strg-F2          (Objekt / Stichwort)&#xa;Object of Code          - Strg-F3          (Codierungsobjekt)&#xa;Question                - Strg-F4          (Frage)&#xa;Open Question           - Strg-F5          (Offene Frage)&#xa;Bad                     - Strg-F6          (Schlecht)&#xa;Blue                    - Strg-F7          (Blau)&#xa;Pink                    - Strg-F8          (Rosa)&#xa;Cyan                    - Strg-F9          (Cyan, ein Blau)&#xa;&#xa;&#xa;Navigieren:&#xa;Wurzel zentrieren           - ESC&#xa;Knoten nach oben schieben   - Strg-Oben&#xa;Knoten nach unten schieben  - Strg-Unten&#xa;Knoten falten/entfalten     - Leertaste&#xa;Unterknoten (ent)falten     - Strg-Leertaste&#xa;Alles aufklappen            - Alt-Ende&#xa;Alles zuklappen             - Alt-Pos1&#xa;Eine Ebene aufklappen       - Alt-Bild ab&#xa;Eine Ebene zuklappen        - Alt-Bild auf&#xa;Hyperlink &#xf6;ffnen:           - Strg-Eingabe&#xa;&#xa;&#xa;Extras:&#xa;Knoten verbinden            - Strg-J&#xa;Kalender anzeigen...        - Strg-T        (Plugin)&#xa;Einstellungen...            - Strg-,&#xa;&#xa;&#xa;Maps:&#xa;Vorherige Map               - Strg-Links&#xa;N&#xe4;chste Map                 - Strg-Rechts&#xa;&#xa;&#xa;Modi:&#xa;MindMap                     - Alt-1   (Baum bearbeiten)&#xa;Browse                      - Alt-2   (Baum betrachten und durchst&#xf6;bern)&#xa;File                        - Alt-3   (Dateisystem betrachten/durchst&#xf6;bern)">
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node COLOR="#006633" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_904501221" MODIFIED="1124560950701" POSITION="left" TEXT="Installation">
<node COLOR="#006699" CREATED="1124560950701" ID="_Freemind_Link_1911559485" MODIFIED="1134673204361" TEXT="Links (Verweise)">
<node CREATED="1124560950701" ID="Freemind_Link_1001926961" LINK="http://java.sun.com/j2se" MODIFIED="1131994815853" TEXT="Laden Sie die Java Laufzeitumgebung herunter (mindestens J2RE1.4).">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1612101865" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1134673114322" TEXT="Laden Sie die Anwendung herunter.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_139664576" MODIFIED="1134673381303" TEXT="Um FreeMind unter Microsoft Windows zu installieren, installieren Sie zun&#xe4;chst Java von Sun und dann FreeMind mit dem FreeMind-Installer."/>
<node CREATED="1124560950701" ID="_Freemind_Link_1380352758" MODIFIED="1134673415131" TEXT="Unter LINUX laden Sie zun&#xe4;chst die passende Java Laufzeitumgebung und dann die FreeMind-Anwendung selbst herunter (Archiv). Zuerst installieren Sie Java, dann entpacken Sie das FreeMind-Archiv. Um FreeMind zu starten, f&#xfc;hren Sie &apos;freemind.sh&apos; aus.&#xa;"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1808511462" MODIFIED="1134673599092" TEXT="Unter Microsoft Windows und Mac OS X k&#xf6;nnen Sie einfach auf die Datei &apos;freemind.jar&apos; doppelklicken. Die Datei finden Sie im Ordner &apos;lib&apos; des FreeMind-Verzeichnisses."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_353522063" MODIFIED="1131995123312" POSITION="left" TEXT="Durchst&#xf6;bern der Dateien auf Ihrem Computer">
<node CREATED="1124560950701" ID="Freemind_Link_629723508" MODIFIED="1131995470138" TEXT="Um die Dateien auf Ihrem Computer zu durchst&#xf6;bern, wechseln Sie in den Datei-Modus, indem Sie im Hauptmen&#xfc; &apos;Modi&apos; den Untermen&#xfc;pukt &apos;File&apos; anklicken."/>
<node CREATED="1124560950701" ID="Freemind_Link_921633025" MODIFIED="1131998178490" TEXT="Sie durchst&#xf6;bern das Dateisystem, als w&#xe4;re es eine Mindmap."/>
<node CREATED="1124560950701" ID="Freemind_Link_1645919012" MODIFIED="1132073146277" TEXT="Um einen Ordner zum zentralen Knoten des Baums zu machen, w&#xe4;hlen Sie im Kontextmen&#xfc; &apos;Zentrieren&apos;."/>
<node CREATED="1124560950701" ID="Freemind_Link_1275316867" MODIFIED="1134673906281" TEXT="Um eine Datei zu betrachten, zu bearbeiten oder auszuf&#xfc;hren, folgen Sie dem Verweis Ihres Knotens (klicken Sie auf den roten Pfeil)."/>
<node CREATED="1124560950701" ID="_Freemind_Link_279880616" MODIFIED="1132073587667" TEXT="Der Dateimodus ist zur Zeit nicht wirklich n&#xfc;tzlich. Er ist eine Demonstration daf&#xfc;r, da&#xdf; es nicht zu schwierig ist, den Baum mit Daten aus anderen Quellen als MindMaps zu beschicken. Es gibt keine Anzeichen daf&#xfc;r, da&#xdf; Leute diesen Modus gegenw&#xe4;rtig benutzen w&#xfc;rden."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1530607683" MODIFIED="1132073635697" POSITION="left" TEXT="Durchst&#xf6;bern von MindMaps">
<node CREATED="1124560950701" ID="Freemind_Link_1053534219" MODIFIED="1132074287957" TEXT="Um MindMaps eher zu durchst&#xf6;bern, als sie zu bearbeiten, schalten Sie in den Browse-Modus, indem Sie im Hauptmen&#xfc; &apos;Modi&apos; den Men&#xfc;punkt &apos;Browse&apos; w&#xe4;hlen. Ausgenommen davon, dass sie in FreeMinds Webbrowser-Erweiterung zum Einsatz kommt, ist diese Funktion nutzlos."/>
<node CREATED="1124560950701" ID="Freemind_Link_1762125143" MODIFIED="1132074496193" TEXT="Die Gr&#xfc;nde f&#xfc;r einen eigenen Browse-Modus sind technischer Art. Browsen (Durchst&#xf6;bern) ist die einzige Sache, die Sie in FreeMinds Webbrowser-Erweiterung tun k&#xf6;nnen, welche Sie auf Ihrer Website (Internet-Seite) verwenden k&#xf6;nnen. Normalerweise w&#xfc;rden Sie den Browse-Modus in FreeMind nicht verwenden."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1136088046" MODIFIED="1132074838644" POSITION="left" TEXT="&#xdc;ber Modi">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1713057526" MODIFIED="1132076116853" TEXT="Obgleich FreeMind in erster Linie ein Werkzeug zum Bearbeiten von MindMaps darstellt, ist es bewu&#xdf;t dazu entworfen, aus verschiedenartigen Quellen kommende Daten zu veranschaulichen. Um eine bestimmte Datenquelle zur Veranschaulichung in FreeMind verf&#xfc;gbar zu machen, hat ein Programmierer einen sogenannten Modus f&#xfc;r diese Datenquelle zu schreiben. Der Datei-Modus ist ein Beispiel. Wir wissen nichts &#xfc;ber irgendwelche anderen verwirklichten Modi. Es ist nicht klar, ob jemand tats&#xe4;chlich Gebrauch von dieser Architektur machen m&#xf6;chte; sie ist dazu da ausgesch&#xf6;pft zu werden, falls jemand das m&#xf6;chte.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_700085988" MODIFIED="1132077145063" TEXT="Es gibt fast fertigen Code (1) f&#xfc;r den Scheme-Modus, welcher es Ihnen erm&#xf6;glicht, Scheme-Programme zu bearbeiten (2). Und wieder gilt, die N&#xfc;tzlichkeit ist weit davon entfernt klar zu sein. Im Gegensatz zum MindMap-Modus sind andere Modi eher eine Demonstration dessen, was m&#xf6;glich ist, nicht dessen, was gegenw&#xe4;rtig in Gebrauch ist.&#xa;---------&#xa;Anm. d. &#xdc;.&#xa;(1) Quelltext f&#xfc;r Computerprogramme&#xa;(2) Scheme ist ein Lisp-Dialekt. Lisp ist eine Programmiersprache f&#xfc;r Computer.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1525986009" MODIFIED="1132077308252" POSITION="left" TEXT="Die FreeMind-Anwendung auf Ihrer Website installieren">
<node COLOR="#000000" CREATED="1124560950701" ID="Freemind_Link_413216341" MODIFIED="1132078361716" TEXT="Sie k&#xf6;nnen die Anwendung auf Ihrer Website (Internetseite) installieren, damit Besucher Ihre MindMaps durchst&#xf6;bern k&#xf6;nnen.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_70391546" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1132077633356" TEXT="Laden Sie die FreeMind-Browser Anwendung herunter."/>
<node CREATED="1124560950701" ID="Freemind_Link_1182574839" MODIFIED="1132077943209" TEXT="Das heruntergeladene Archiv enthaelt die Dateien &apos;freemindbrowser.jar&apos; und &apos;freemindbrowser.html&apos;. Erzeugen Sie einen Link (Verweis) von Ihrer Seite zur Datei &apos;freemindbrowser.html&apos;. &#xc4;ndern Sie in der Datei &apos;freemindbrowser.html&apos; die verweisende Pfadangabe, so da&#xdf; sie auf Ihre MindMap zeigt."/>
<node CREATED="1124560950701" ID="Freemind_Link_1992245682" MODIFIED="1134674470963" TEXT="Aus Java(1)-Sicherheitsgr&#xfc;nden mu&#xdf; sich die &apos;.jar&apos;-Datei der Anwendung auf dem selben Server wie die MindMap selbst befinden. Sie m&#xfc;ssen die Freemind-Anwendung und Ihre MindMap-Datei auf Ihre Website hochladen.&#xa;--------&#xa;anm.d.&#xdc;.&#xa;(1) Java ist eine Laufzeitumgebung, die das Ausf&#xfc;hren von daf&#xfc;r geschriebenen Programmen unabh&#xe4;ngig von der benutzten Computer-Hardware erm&#xf6;glicht."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1083756111" MODIFIED="1132078415764" POSITION="left" TEXT="Die FreeMind-Anwendung benutzen">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_514864900" MODIFIED="1134674611176" TEXT="In der FreeMind-Anwendung k&#xf6;nnen Sie nur den Browse-Modus benutzen; Sie k&#xf6;nnen keine (entfernt im Internet liegenden) MindMaps bearbeiten. Klicken Sie auf einen Knoten, um ihn auf oder zu zu klappen oder um einem Link (Verweis) zu folgen. Klicken Sie mauslinks in den Hintergrund und bewegen Sie Ihre Computermaus bei gedr&#xfc;ckt gehaltener Maustaste, um die MindMap zu bewegen. Um die MindMap zu durchsuchen, benutzen Sie das Knoten-Kontextmen&#xfc; (mausrechts auf einen Knoten klicken).">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1976458022" MODIFIED="1132079047686" POSITION="left" TEXT="&#xc4;nderungen der Benutzerschnittstelle in Version 0.6.5">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_717349033" MODIFIED="1134675457085" TEXT="Einige der Tastaturk&#xfc;rzel wurden umdefiniert, soda&#xdf; sie mit dem, was wir als gemeinsamen Standard oder intuitive Benutzung betrachten, abgeglichen sind. Einige der neuen Tastaturk&#xfc;rzel haben Microsoft Werkzeuge zum Vorbild. Die neuen Tastaturk&#xfc;rzel schlie&#xdf;en &apos;Enter&apos; (bzw. Eingabetaste) zum Erzeugen von Geschwistern unterhalb eines Knotens, &apos;Einfg&apos; um neue Knotenkinder zu erzeugen und &apos;F2&apos; um Knoten zu bearbeiten ein. Bei &apos;F2&apos; wird der Microsoft-Einflu&#xdf; sichtbar, denn es gibt keinen intuitiven Grund, warum &apos;F2&apos; zum Bearbeiten von Knoten f&#xfc;hren sollte. Aber sobald Sie das in all den von Ihnen genutzten Programmen gewohnt sind, wollen Sie das auch in FreeMind haben.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1179893656" MODIFIED="1132080574562" TEXT="Die Tastaturk&#xfc;rzel k&#xf6;nnen in der Dialogbox &apos;Freemind Properties&apos;, Abteilung &apos;Tasten&apos;, ge&#xe4;ndert werden. Diese Dialogbox rufen Sie &#xfc;ber den Hauptmen&#xfc;punkt &apos;Extras&apos;, Untermen&#xfc; &apos;Einstellungen...&apos;, auf.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_784043927" MODIFIED="1134676131335" POSITION="left" TEXT="Danksagungen">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_415458128" MODIFIED="1134675884268" TEXT="Autoren">
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1896457660" MODIFIED="1124560950701" TEXT="Joerg Mueller">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:ponders@t-online.de" MODIFIED="1124560950701" TEXT="ponders@t-online.de">
<font NAME="Dialog" SIZE="10"/>
</node>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1506212831" MODIFIED="1134675848054" TEXT="Universit&#xe4;t Freiburg, Deutschland">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_984984595" LINK="http://mujweb.cz/www/danielpolansky" MODIFIED="1124560950701" TEXT="Daniel Polansky">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_459203293" MODIFIED="1124560950701" TEXT="Petr Novak">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_875814410" MODIFIED="1124560950701" TEXT="Christian Foltin">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:christian.foltin@gmx.de" MODIFIED="1124560950701" TEXT="christian.foltin@gmx.de">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1415293905" MODIFIED="1124560950701" TEXT="Dimitri Polivaev">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_816166020" MODIFIED="1134675956405" TEXT="Kleinere Beitr&#xe4;ge">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_550065345" MODIFIED="1124560950701" TEXT="Andrew Iggleden">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Installer Windows">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1096673251" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Eclipse howto">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1024053399" MODIFIED="1124560950701" TEXT="David Butt">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Tutorial flash">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1026710206" MODIFIED="1124560950701" TEXT="David Low">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Helpful">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_360501151" MODIFIED="1134675973235" TEXT="&#xdc;bersetzungen">
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_807977431" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Italian translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1853214917" MODIFIED="1124560950701" TEXT="Knud Riish&#xf8;jg&#xe5;rd">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Danish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1676529317" MODIFIED="1124560950701" TEXT="Takeshi Kakeda">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562983644" ID="Freemind_Link_1172193026" MODIFIED="1124562984816" TEXT="Kohichi Aoki">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1781005784" MODIFIED="1124560950701" TEXT="Alex Dukal">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562998159" ID="Freemind_Link_757563697" MODIFIED="1124563008034" TEXT="Hugo Gayosso">
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1783275246" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_929540960" MODIFIED="1124560950701" TEXT="Sylvain Gamel">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="French translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" ID="Freemind_Link_946171164" MODIFIED="1124561245019" TEXT="Koen Roggemans">
<node COLOR="#999999" CREATED="1124561245957" ID="Freemind_Link_1819881845" MODIFIED="1124561251675" TEXT="Dutch translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" ID="Freemind_Link_235962981" MODIFIED="1124561376718" TEXT="Rafal Kraik">
<node COLOR="#999999" CREATED="1124561377702" ID="Freemind_Link_459079511" MODIFIED="1124561382155" TEXT="Polish translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561969717" ID="Freemind_Link_653284985" MODIFIED="1124561972920" TEXT="Goliath">
<node COLOR="#999999" CREATED="1124561438294" ID="Freemind_Link_1387213811" MODIFIED="1124561445950" TEXT="Korean translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561753254" ID="Freemind_Link_35211963" MODIFIED="1124563712385" TEXT="Miles a.k.a. filmsi">
<node COLOR="#999999" CREATED="1124561491886" ID="Freemind_Link_835144271" MODIFIED="1124561506386" TEXT="Slovenian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561814721" ID="Freemind_Link_1008886206" MODIFIED="1124561818580" TEXT="William Chen">
<node COLOR="#999999" CREATED="1124561497308" ID="Freemind_Link_1960552629" MODIFIED="1124561506011" TEXT="Chinese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561823877" ID="Freemind_Link_1650138043" MODIFIED="1124561876907" TEXT="Radek &#x160;varc">
<node COLOR="#999999" CREATED="1124561515761" ID="Freemind_Link_768227373" MODIFIED="1124561519885" TEXT="Czech translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562250475" ID="Freemind_Link_901975324" MODIFIED="1124562252007" TEXT="Bal&#xe1;zs M&#xe1;rton">
<node COLOR="#999999" CREATED="1124562252585" ID="Freemind_Link_557911120" MODIFIED="1124562258428" TEXT="Hungarian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562948942" ID="Freemind_Link_290351026" MODIFIED="1124562950270" TEXT="Luis Ferreira ">
<node COLOR="#999999" CREATED="1124562956332" ID="Freemind_Link_6081004" MODIFIED="1124562961879" TEXT="Portuguese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1132080912443" ID="Freemind_Link_1387051946" LINK="mailto:christof.raber@raber.net" MODIFIED="1132080973491" TEXT="Christof Raber">
<edge COLOR="#808080" WIDTH="thin"/>
<node COLOR="#999999" CREATED="1132080978203" ID="Freemind_Link_694499371" MODIFIED="1134675764996" TEXT="Deutsche &#xdc;bersetzung der Hilfedatei freemind.mm  (V.0.8.0, zuletzt bearbeitet: 15.12.2005)">
<edge COLOR="#808080" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124563066204" ID="Freemind_Link_23652566" MODIFIED="1134676836086" TEXT="Die Danksagungen f&#xfc;r die &#xdc;bersetzungen sind wahrscheinlich unvollst&#xe4;ndig. Wenn wir Sie vergessen haben, lassen Sie es und wissen. Alle Leute , von denen wir wissen, da&#xdf; sie zumindest eine unvollst&#xe4;ndige &#xdc;bersetzung beigetragen haben, sind aufgef&#xfc;hrt. ">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="Freemind_Link_397889068" MODIFIED="1132081365511" POSITION="right" TEXT="Dr&#xfc;cken Sie &apos;Strg&apos; + &apos;F&apos; um vom aktuellen Knoten aus abw&#xe4;rts zu suchen. Dr&#xfc;cken Sie &apos;Strg&apos; + &apos;G&apos; um die Suche fortzusetzen. Um im ganzen MindMap-Baum zu suchen, dr&#xfc;cken Sie &apos;Esc&apos; bevor Sie mit Ihrer Suche beginnen."/>
<node COLOR="#0033ff" CREATED="1124560950701" ID="Freemind_Link_178218424" MODIFIED="1134676932150" POSITION="right" TEXT="Dr&#xfc;cken Sie die Pfeil-rechts-Taste um eine Textbox zu entfalten.&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;Dies funktioniert so nicht in jedem Fall (Textboxen/Baumknoten links vom Hauptknoten), besser: Dr&#xfc;cken Sie die Leertaste, um Knoten zu entfalten / zu falten."/>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1596161299" MODIFIED="1132081507436" POSITION="right" TEXT="Einf&#xfc;hrung">
<node CREATED="1124560950701" ID="Freemind_Link_1177570666" MODIFIED="1132081907600" TEXT="FreeMind macht es m&#xf6;glich, sogenannte MindMaps zu erzeugen. Viele Leute nutzen es auch als Alternative zu einem in Abteilungen unterteilten Notizbuch oder als pers&#xf6;nlichen Informationsmanager."/>
<node CREATED="1124560950701" ID="Freemind_Link_1022362781" MODIFIED="1132083616673" TEXT="Information wird in Textboxen gelagert, sogenannten Knoten. Knoten sind miteinander durch Kurvenlinien verbunden, sogenannten B&#xf6;gen(1).&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;(1) In den Funktionsmen&#xfc;s von FreeMind auch als Kanten (Hauptbedeutung des englischen Begriffs &apos;edge&apos;) bezeichnet."/>
<node CREATED="1124560950701" ID="Freemind_Link_1207466374" MODIFIED="1132083518178" TEXT="Dies ist eine Dokumentation f&#xfc;r FreeMind 0.8.0. Tastaturk&#xfc;rzel und die Lage von Funktionen in Men&#xfc;s kann sich von Version zu Version ver&#xe4;ndern.&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;Die Angaben zu Men&#xfc;funktionen und Tastaturk&#xfc;rzeln wurden von mir nicht 1:1 &#xfc;bersetzt, sondern mit der in FreeMind 0.8.0 vorgefundenen Funktionalit&#xe4;t abgeglichen.   "/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_706084071" MODIFIED="1132083002632" POSITION="right" TEXT="Demonstration einiger F&#xe4;higkeiten">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_735193624" MODIFIED="1132090125392" TEXT="Erscheinungsbild">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1352457599" MODIFIED="1132241398960" TEXT="Es gibt Knoten in verschiedene Farben">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1124560950701" ID="Freemind_Link_719425520" MODIFIED="1132083999386" TEXT="rot">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#009900" CREATED="1124560950701" ID="Freemind_Link_238761209" MODIFIED="1132084010272" TEXT="gr&#xfc;n">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0000cc" CREATED="1124560950701" ID="Freemind_Link_358373706" MODIFIED="1132084018696" TEXT="blau">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_" MODIFIED="1132241402531" TEXT="Es gibt Knoten in mancherlei Hintergrundfarben">
<node BACKGROUND_COLOR="#ff99cc" CREATED="1124560950701" ID="_Freemind_Link_1358611533" MODIFIED="1132084133012" TEXT="diese"/>
<node BACKGROUND_COLOR="#6699ff" CREATED="1124560950701" ID="_Freemind_Link_1317973766" MODIFIED="1132084140350" TEXT="jene"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_177707040" MODIFIED="1132241406207" TEXT="Es gibt Knoten in verschiedenen Schriftstilen">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_876078064" MODIFIED="1132084208779" TEXT="fett">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_681299271" MODIFIED="1132084217577" TEXT="kursiv">
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1786244566" MODIFIED="1132084229042" TEXT="fett und kursiv">
<font BOLD="true" ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_13384967" MODIFIED="1132241410225" TEXT="Es gibt Knotenschrift in verschiedenen Gr&#xf6;&#xdf;en">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_1555487589" MODIFIED="1132090261417" TEXT="klein">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="normal">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_185102650" MODIFIED="1132090275419" TEXT="gr&#xf6;&#xdf;er">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_133607989" MODIFIED="1132090302273" TEXT="ganz gro&#xdf;">
<font NAME="SansSerif" SIZE="20"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="OOh">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_781892119" MODIFIED="1132241414401" TEXT="Verschiedene Schriftfamilien d&#xfc;rfen genutzt werden">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_173087886" MODIFIED="1132090464065" TEXT="dieser">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1568731425" MODIFIED="1132090476758" TEXT="oder jener">
<font NAME="Verdana" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1672236398" MODIFIED="1132090495013" TEXT="oder der da">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1193071041" MODIFIED="1132090534724" TEXT="Verschiedene Knotenstile k&#xf6;nnen genutzt werden.">
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1979277285" MODIFIED="1132090583026" TEXT="Verzweigung">
<node CREATED="1124560950701" ID="_Freemind_Link_89124429" MODIFIED="1132090590284" TEXT="Verzweigung"/>
<node CREATED="1124560950701" ID="_Freemind_Link_173850525" MODIFIED="1132090597377" TEXT="Verzweigung"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1001811541" MODIFIED="1132090649687" STYLE="bubble" TEXT="Blase">
<node CREATED="1124560950701" ID="_Freemind_Link_1677737286" MODIFIED="1132090660165" STYLE="bubble" TEXT="Blase"/>
<node CREATED="1124560950701" ID="_Freemind_Link_978246353" MODIFIED="1132090668327" STYLE="bubble" TEXT="Blase"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_757728721" MODIFIED="1132090743730" TEXT="Knoten k&#xf6;nnen gefaltet sein">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_307016912" MODIFIED="1132090789816" TEXT="gefaltet">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_748957810" MODIFIED="1132090801442" TEXT="versteckt">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1488567837" MODIFIED="1132090813128" TEXT="Baum">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_370913262" MODIFIED="1132090842939" TEXT="Eiche">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_355277376" MODIFIED="1132094645230" TEXT="Buche">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1784692550" MODIFIED="1132094682634" TEXT="Ulme">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1885250534" MODIFIED="1132094746933" TEXT="Knoten k&#xf6;nnen verfolgbare Verweise enthalten. Zu ...">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_796978285" MODIFIED="1132094912859" TEXT="Internet-Seiten">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" LINK="http://www.google.com/" MODIFIED="1124560950701" TEXT="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1010545300" LINK="www.google.com" MODIFIED="1124560950701" TEXT="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1591226954" MODIFIED="1132094821420" TEXT="Freemind denkt, dies ist ausf&#xfc;hrbar :)">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1119935059" MODIFIED="1132094896971" TEXT="lokalen Ordnern">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_1060370167" LINK="C:/Program%20Files/" MODIFIED="1132094855904" TEXT="C:/Programme/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" LINK="/home/" MODIFIED="1124560950701" TEXT="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1008386972" MODIFIED="1132094998312" TEXT="ausf&#xfc;hrbaren Programmen">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_661824400" LINK="%SystemRoot%\regedit.exe" MODIFIED="1124560950701" TEXT="%SystemRoot%\regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006600" CREATED="1124560950701" ID="Freemind_Link_1441814137" MODIFIED="1132095064759" TEXT="Sie sehen am Piktogramm, da&#xdf; der Knoten ausf&#xfc;hrbar ist.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_76567274" MODIFIED="1132095129024" TEXT="jedem Dokument auf Ihrem lokalen Computer oder dem Netzwerk Ihrer Firma">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_839677176" MODIFIED="1132095174501" TEXT="Mehrzeilige Knoten">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1423568963" MODIFIED="1132096446195" TEXT="Sie k&#xf6;nnen mehrzeilige Knoten als Abs&#xe4;tze oder als einzelne Abschnitte betrachten. Wenn Sie darangehen, Wissensdatenbanken mit FreeMind zu erstellen, f&#xfc;hrt kein Weg daran vorbei. Anstelle einer schlichten Testdatei f&#xfc;r Ihren Notizensatz k&#xf6;nnen Sie einen kurzen Knoten mit vielen mehrzeiligen Kinderknoten haben."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1686184172" MODIFIED="1132096319719" TEXT="&quot;Science is facts; just as houses are made of stones, so is science made of facts; but a pile of stones is not a house and a collection of facts is not necessarily science.&quot; --Henri Poincar&#xe9;&#xa;(Wissenschaft sind Fakten. Genau wie H&#xe4;user aus Steinen gemacht sind, so ist Wissenschaft aus Fakten gemacht. Aber ein Haufen Steine ist kein Haus und eine Sammlung von Fakten ist nicht notwendigerweise Wissenschaft.)"/>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1255169413" MODIFIED="1132096371520" TEXT="Kurze, mehrzeilige Knoten mit Zeilenumbr&#xfc;chen">
<node CREATED="1124560950717" ID="_Freemind_Link_1957797574" MODIFIED="1132096717324" TEXT="Eine Zeile,&#xa;und eine zweite&#xa;&#xa;und noch eine andere werden es tun,&#xa;also was denken Sie dar&#xfc;ber?"/>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_14045206" MODIFIED="1132096868057" TEXT="Sie k&#xf6;nnen beschriftete B&#xf6;gen nachahmen">
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_437606861" MODIFIED="1132096878185" TEXT="Baum">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1494572903" MODIFIED="1132096908905" TEXT="ist eine">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1780289562" MODIFIED="1132240811030" TEXT="Eiche" VSHIFT="1">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_369010689" MODIFIED="1132096926002" TEXT="ist eine">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" HGAP="22" ID="Freemind_Link_1121488557" MODIFIED="1132240807912" TEXT="Buche" VSHIFT="1">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_570579933" MODIFIED="1132096941955" TEXT="ist eine">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_556181970" MODIFIED="1132240799226" TEXT="Ulme" VSHIFT="1">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1013650868" MODIFIED="1132096958045" TEXT="Baum">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1167897167" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" HGAP="21" ID="Freemind_Link_1554280421" MODIFIED="1132240817894" TEXT="Blatt" VSHIFT="1">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_783431562" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1549850763" MODIFIED="1132240830471" TEXT="Stamm" VSHIFT="1">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="Freemind_Link_242957031" MODIFIED="1132241130096" TEXT="Es gibt Piktogramme in Knoten">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_318937820" MODIFIED="1132241517501" TEXT="Es gibt Wolken">
<cloud/>
<node CREATED="1124560950717" ID="Freemind_Link_913111155" MODIFIED="1132241526410" TEXT="in ma&#xdf;geschneiderten Farben">
<cloud COLOR="#f1ede6"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1750585847" MODIFIED="1132241548507" TEXT="Es gibt graphische Verweise">
<node CREATED="1124560950717" ID="_Freemind_Link_1212380407" MODIFIED="1132097368688" TEXT="Verbindender Knoten">
<arrowlink DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="44;0;" ID="Arrow_ID_139975992" STARTARROW="None" STARTINCLINATION="46;2;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1249400461" MODIFIED="1132097368693" TEXT="zu einem anderen">
<arrowlink COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" STARTARROW="None" STARTINCLINATION="47;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="44;0;" ID="Arrow_ID_139975992" SOURCE="_Freemind_Link_1212380407" STARTARROW="None" STARTINCLINATION="46;2;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_880551392" MODIFIED="1132241563432" TEXT="in verschiedenen Farben">
<arrowlink DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="82;44;" ID="Freemind_Arrow_Link_1672464612" STARTARROW="None" STARTINCLINATION="82;44;"/>
<linktarget COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" SOURCE="_Freemind_Link_1249400461" STARTARROW="None" STARTINCLINATION="47;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1789233193" MODIFIED="1132097490228" TEXT="und unterschiedlicher Anlenkung">
<linktarget COLOR="#b0b0b0" DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="82;44;" ID="Freemind_Arrow_Link_1672464612" SOURCE="_Freemind_Link_880551392" STARTARROW="None" STARTINCLINATION="82;44;"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_127668276" MODIFIED="1132097551326" TEXT="Knoten k&#xf6;nnen frei positioniert werden">
<node CREATED="1124560950717" ID="_Freemind_Link_894936766" MODIFIED="1132097570818" TEXT="Einer"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1942481455" MODIFIED="1132097582284" TEXT="Ein anderer" VSHIFT="1"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1709752669" MODIFIED="1132240028390" POSITION="right" TEXT="Knoten erzeugen und l&#xf6;schen">
<node CREATED="1124560950717" ID="Freemind_Link_168416055" MODIFIED="1132240224989" TEXT="Um einen Kinderknoten zu erzeugen, dr&#xfc;cken Sie &apos;Einfg&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_19900654" MODIFIED="1132240303467" TEXT="Um einen Kinderknoten zu erzeugen, w&#xe4;herend Sie einen Knoten bearbeiten, dr&#xfc;cken Sie &apos;Einfg&apos; w&#xe4;hrend der Bearbeitung."/>
<node CREATED="1124560950717" ID="Freemind_Link_958397576" MODIFIED="1132240463347" TEXT="Um einen nachfolgenden Geschwisterknoten zu erzeugen, dr&#xfc;cken Sie &apos;Enter&apos; oder die Eingabetaste."/>
<node CREATED="1124560950717" ID="Freemind_Link_392769746" MODIFIED="1132240614380" TEXT="Um einen vorausgehenden Geschwisterknoten zu erzeugen, dr&#xfc;cken Sie Umschalttaste + Eingabetaste oder Umschalttaste + &apos;Enter&apos;. "/>
<node CREATED="1124560950717" ID="Freemind_Link_642872701" MODIFIED="1132240686449" TEXT="Um einen Knoten zu entfernen, dr&#xfc;cken Sie &apos;Entf&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_1532941422" MODIFIED="1132240773910" TEXT="Um einen Knoten zum Wiedereinf&#xfc;gen an anderer Stelle zu entfernen, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;X&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_1510813723" MODIFIED="1132240983358" TEXT="Alternativ nutzen Sie das Knoten-Kontextmen&#xfc;, indem Sie mausrechts auf den Knoten klicken."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1700974092" MODIFIED="1132097619367" POSITION="right" TEXT="Knotentext bearbeiten">
<node CREATED="1124560950717" ID="_Freemind_Link_519923426" MODIFIED="1132098029437" TEXT="Um einen Knoten zu bearbeiten, dr&#xfc;cken Sie die &apos;F2&apos;-, &apos;Pos1&apos;- oder &apos;Ende&apos;-Taste, oder Sie benutzen &apos;Knoten bearbeiten&apos; im Kontextmen&#xfc; des Knotens. Um das Bearbeiten eines Knotens abzuschlie&#xdf;en, dr&#xfc;cken Sie &apos;Enter&apos; bzw. die Eingabe-Taste.">
<arrowlink DESTINATION="_Freemind_Link_519923426" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_1179992477" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="_Freemind_Link_519923426" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_1179992477" SOURCE="_Freemind_Link_519923426" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1825283901" MODIFIED="1132097769227" TEXT="Um den Text in einem Knoten mit einem neuen zu ersetzen, fangen Sie an zu Tippen."/>
<node CREATED="1124560950717" ID="Freemind_Link_363486573" MODIFIED="1132098536483" TEXT="Um das Fenster zum Bearbeiten von umfangreichen Knoten (Langtexteditor)) aufzurufen, wenn Sie einen kleinen Knoten bearbeiten, dr&#xfc;cken Sie &apos;Alt&apos; + &apos;Enter&apos; (bzw. &apos;Alt&apos; + Eingabetaste)."/>
<node CREATED="1124560950717" ID="Freemind_Link_1828895192" MODIFIED="1132098667239" TEXT="Um einen langen Knoten aufzuteilen, benutzen Sie den Knopf &apos;Teilen&apos; oben im Langtexteditor, oder dr&#xfc;cken Sie &apos;Alt&apos; + &apos;S&apos; im Langtexteditor.&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;Der Knoten wird an der Stelle geteilt, an der sich der Schreibzeiger (Cursor) befindet."/>
<node CREATED="1124560950717" ID="Freemind_Link_1578669295" MODIFIED="1132099711805" TEXT="Um einen Zeilenumbruch im Langtexteditor einzuf&#xfc;gen, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;Enter&apos; (bzw. &apos;Alt&apos; + Eingabetaste). Sie k&#xf6;nnen keine Zeilenumbr&#xfc;che beim direkten Bearbeiten des Knotens (Kurztexteditor) einf&#xfc;gen.">
<arrowlink DESTINATION="_Freemind_Link_1445647544" ENDARROW="Default" ENDINCLINATION="118;0;" ID="Freemind_Arrow_Link_1628309717" STARTARROW="None" STARTINCLINATION="118;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1491144775" MODIFIED="1132099588177" TEXT="Um w&#xe4;hrend der Bearbeitung im Langtexteditor eine ausgew&#xe4;hlte Textpassage in die Zwischenablage zu kopieren, klicken Sie mit dem rechten Mausknopf und w&#xe4;hlen &apos;Kopieren&apos; im Kontextmen&#xfc;."/>
<node CREATED="1124560950717" ID="Freemind_Link_269218148" MODIFIED="1132100346807" TEXT="Um ein Sonderzeichen wie &#xa9; einzuf&#xfc;gen, f&#xfc;gen Sie es zun&#xe4;chst (mit der dort daf&#xfc;r vorgesehenen Funktion) in Ihre Lieblingstextverarbeitung wie etwa Microsoft Word (oder OpenOffice.org Writer, Anm.d.&#xdc;.) ein und kopieren es dann &#xfc;ber die Zwischenablage in FreeMind."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1445647544" MODIFIED="1132101375694" TEXT="Nach Vorgabe beendet &apos;Enter&apos; (bzw. die Eingabetaste) die Bearbeitung im Langtexteditor und &apos;Strg&apos; + &apos;Enter&apos; (bzw. &apos;Strg&apos; + Eingabetaste) f&#xfc;gt einen Zeilenumbruch ein. Durch Umschalten des Schalters &apos;Eingabetaste schlie&#xdf;t das Fenster&apos; k&#xf6;nnen Sie die Funktion der betreffenden Tasten(kombinationen) umkehren, das hei&#xdf;t &apos;Enter&apos; (bzw. die Eingabetaste) f&#xfc;gt einen Zeilenumbruch ein und &apos;Strg&apos; + &apos;Enter&apos; (bzw. &apos;Strg&apos; + Eingabetaste) beendet die Bearbeitung. Sie k&#xf6;nnen den Vorgabewert dieses Schalters in den Programmeinstellungen setzen. Dar&#xfc;ber hinaus merkt sich FreeMind die Schalterstellung w&#xe4;hrend der aktuellen Sitzung. ">
<linktarget COLOR="#b0b0b0" DESTINATION="_Freemind_Link_1445647544" ENDARROW="Default" ENDINCLINATION="118;0;" ID="Freemind_Arrow_Link_1628309717" SOURCE="Freemind_Link_1578669295" STARTARROW="None" STARTINCLINATION="118;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_879243196" MODIFIED="1132101517602" TEXT="FreeMind unterst&#xfc;tzt Unicode vollst&#xe4;ndig. Dadurch k&#xf6;nnen Sie den Zeichensatz Ihrer Wahl benutzen."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1660149394" MODIFIED="1132241653772" POSITION="right" TEXT="Einen Knoten formatieren">
<node CREATED="1124560950717" ID="Freemind_Link_1344799304" MODIFIED="1134577875208" TEXT="Um einen Knoten fett darzustellen, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;B&apos;.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_603057469" MODIFIED="1134577890516" TEXT="Um einen Knoten kursiv darzustzellen, dr&#xfc;cken Sie &apos;Strg&apos;  + &apos;I&apos;.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1078339400" MODIFIED="1132241853538" TEXT="Um die Textfarbe eines Knotens zu &#xe4;ndern, dr&#xfc;cken Sie &apos;Alt&apos; + &apos;C&apos;.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1354097122" MODIFIED="1132242237237" TEXT="Um die Hintergrundfarbe eines Knotens zu &#xe4;ndern, gehen Sie im Kontextmen&#xfc; &#xfc;ber &apos;Format&apos; und benutzen im erscheinenden Untermen&#xfc; &apos;Knotenhintergrundfarbe...&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_1451037982" MODIFIED="1132242422091" TEXT="Um Knotenschrift zu vergr&#xf6;&#xdf;ern, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;+&apos; (nicht &apos;+&apos; auf dem Ziffernblock).">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_495010614" MODIFIED="1134578735084" TEXT="Um Knotenschrift zu verkleinern, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;-&apos; (nicht &apos;-&apos; auf dem Ziffernblock).">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1919677998" MODIFIED="1134578843255" TEXT="Um die Schrift zu wechseln, benutzen Sie das Auswahlfeld in der Hauptfunktionsleiste."/>
<node CREATED="1124560950717" ID="Freemind_Link_1270201498" MODIFIED="1134578878192" TEXT="Zum Kopieren der Formatierungen eines Knotens dr&#xfc;cken Sie &apos;Alt&apos; + &apos;C&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_757233589" MODIFIED="1132242816138" TEXT="Um Formatierungen auf einen Knoten zu kopieren, dr&#xfc;cken Sie &apos;Alt&apos; + &apos;V&apos;."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_526328879" MODIFIED="1132244076733" POSITION="right" TEXT="Stile benutzen">
<node CREATED="1124560950717" ID="Freemind_Link_1212727626" MODIFIED="1132244426690" TEXT="Um einen Stil auf einen Knoten anzuwenden, w&#xe4;hlen Sie ihn im Kontextmen&#xfc; &#xfc;ber den Eintrag &apos;Stile&apos; aus. Um die Anwendung von Stilen zu beschleunigen, verwenden Sie die im Knoten-Kontextmen&#xfc; gezeigten Tastaturk&#xfc;rzel."/>
<node CREATED="1124560950717" ID="Freemind_Link_32969878" MODIFIED="1132244665223" TEXT="Als technisch versierter Anwender bearbeiten Sie die Datei &apos;patterns.xml&apos; im Ordner &apos;.freemind&apos; Ihres Heimatverzeichnisses, um Ihren eigenen Stil hinzuzuf&#xfc;gen."/>
<node CREATED="1124560950717" ID="Freemind_Link_159180814" MODIFIED="1150324296013">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    [Diese Hilfe ist veraltet.] Eine Anmerkung zur Datei 'patterns.xml' folgt: Ein Stil ist auf einen Knoten anwendbar, wenn er eine &lt;node&gt;-Auszeichnung enth&#xe4;lt. Er ist auf einen Bogen (eine Kante) anwendbar, wenn er eine &lt;edge&gt;-Auszeichnung enth&#xe4;lt. &lt;node&gt;-Auszeichnungen k&#xf6;nnen <font>-Auszeichnungen enthalten. Studieren Sie die mit FreeMind gelieferte Datei 'patterns.xml'.</font>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1697687428" MODIFIED="1132245544041" POSITION="right" TEXT="Knoten durch Wolken hervorheben">
<node CREATED="1124560950717" ID="Freemind_Link_243451486" MODIFIED="1132245791432" TEXT="Wolken sind gut geeignet, um einen Bereich hervorzuheben. Der Knoten und alle seine Unterknoten werden hervorgehoben."/>
<node CREATED="1124560950717" ID="Freemind_Link_1187374691" MODIFIED="1132245974033" TEXT="Um eine Wolke hinzuzuf&#xfc;gen, dr&#xfc;cken Sie &apos;Strg&apos; + Umschalttaste + &apos;B&apos;. Oder w&#xe4;hlen Sie &apos;Wolke&apos; &#xfc;ber den Kontextmen&#xfc;punkt &apos;Einf&#xfc;gen&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_1484701485" MODIFIED="1132328021365" TEXT="Um die Wolkenfarbe zu &#xe4;ndern, w&#xe4;hlen Sie &apos;Wolkenfarbe...&apos; &#xfc;ber das Knoten-Kontextmen&#xfc; &apos;Format&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_1602094025" MODIFIED="1132246144994" TEXT="Wolken k&#xf6;nnen &#xfc;ber verschiedene Hintergrundfarben verf&#xfc;gen: gr&#xfc;n ... ">
<cloud COLOR="#e1f2e1"/>
<node CREATED="1124560950717" ID="Freemind_Link_362994334" MODIFIED="1132246131375" TEXT="... oder braun.">
<cloud COLOR="#ede5d5"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_203858515" MODIFIED="1132328112331" POSITION="right" TEXT="Querverweis hinzuf&#xfc;gen">
<node CREATED="1124560950717" ID="Freemind_Link_1867388527" MODIFIED="1134579566800" TEXT="Um zu einem Knoten einen Querverweis (Hyperlink) hinzu zu f&#xfc;gen, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;K&apos; oder w&#xe4;hlen Sie &apos;Querverweis&apos; &#xfc;ber den Knoten-Kontextmen&#xfc;punkt &apos;Einf&#xfc;gen&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_743396731" MODIFIED="1134580044924" TEXT="Um einen Querverweis zu entfernen, l&#xf6;schen Sie ihn, nachdem Sie mit &apos;Strg&apos; + &apos;K&apos; seine Bearbeitung aufgerufen haben."/>
<node CREATED="1124560950717" ID="Freemind_Link_1897919343" MODIFIED="1134585164239">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    Um auf eine eMail-Adresse zu verweisen, setzen Sie den Querverweis als <i>mailto:don.bonton@supermail.com</i>.<br/>--------<br/>Anm.d.&#xdc;.<br/>Wobei Sie anstatt <i>don.bonton@supermail.com</i> nat&#xfc;rlich die von Ihnen gew&#xfc;nschte eMail-Adresse eintragen.
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<linktarget COLOR="#b0b0b0" DESTINATION="Freemind_Link_1897919343" ENDARROW="Default" ENDINCLINATION="740;0;" ID="Freemind_Arrow_Link_1804503188" SOURCE="Freemind_Link_851316277" STARTARROW="None" STARTINCLINATION="740;0;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1054419207" MODIFIED="1134585176517">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    Um auf eine eMail-Adresse zu verweisen und gleich einen Betreff f&#xfc;r die eMail mitzugeben,<br/>setzen Sie den Querverweis in folgender Form: <i>mailto:don.bonton@supermail.com?subject=Last phone call</i>.<br/>--------<br/>Anm.d.&#xdc;.<br/>Wobei Sie anstatt <i>don.bonton@supermail.com</i> ebenfalls die von Ihnen gew&#xfc;nschte eMail-Adresse und<br/>anstatt <i>Last phone call</i> den von Ihnen gew&#xfc;nschten Betreff eintragen.
  </body>
</html></richcontent>
<linktarget COLOR="#b0b0b0" DESTINATION="Freemind_Link_1054419207" ENDARROW="Default" ENDINCLINATION="722;0;" ID="Freemind_Arrow_Link_1534504502" SOURCE="Freemind_Link_13384265" STARTARROW="None" STARTINCLINATION="722;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1753886221" MODIFIED="1132329635860" TEXT="Querverweise k&#xf6;nnen Knoten mit Seiten im Internet, lokalen (oder Netzwerk-) Dateien oder eMail-Adressen verbinden.&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;Dar&#xfc;berhinaus k&#xf6;nnen Sie ausf&#xfc;hrbare Programme verkn&#xfc;pfen und dann durch klicken auf den Verweis starten."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1044397139" MODIFIED="1134580510091" POSITION="right" TEXT="Piktogramme hinzuf&#xfc;gen.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1013069736" MODIFIED="1132329720289" TEXT="Ein Knoten kann &#xfc;ber mehrere Piktogramme (Icons) verf&#xfc;gen."/>
<node CREATED="1124560950717" ID="Freemind_Link_1095906947" MODIFIED="1134580571475" TEXT="Um einen Knoten um Piktogramme zu erg&#xe4;nzen, w&#xe4;hlen Sie einen Knoten und klicken dann auf eines der Piktogramme, die Sie auf der Werkzeugleiste am linken Fensterrand sehen. W&#xe4;hrend Sie den Mauszeiger zur linken Werkzeugleiste bewegen, halten Sie die &apos;Alt&apos;-Taste oder die &apos;Strg&apos;-Taste gedr&#xfc;ckt, damit der gew&#xe4;hlte Knoten nicht den Focus verliert."/>
<node CREATED="1124560950717" ID="Freemind_Link_1330122246" MODIFIED="1134580619132" TEXT="Um ein Piktogramm wieder zu entfernen, klicken Sie auf das rote Kreuz oben auf der Piktogrammleiste.&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;Es wird jeweils das zuletzt dem Knoten hinzugef&#xfc;gte Piktogramm gel&#xf6;scht."/>
<node CREATED="1124560950717" ID="Freemind_Link_368603077" MODIFIED="1132331524245" TEXT="Um alle Piktogramme zu entfernen, klicken Sie auf das M&#xfc;lleimersymbol oben auf der Piktogrammleiste."/>
<node CREATED="1124560950717" ID="Freemind_Link_1783760244" MODIFIED="1132333559586" TEXT="Um den gew&#xe4;hlten Knoten um ein Piktogramm zu erg&#xe4;nzen, ohne die Piktogrammleiste am linken Fensterrand zu benutzen, dr&#xfc;cken Sie &apos;Alt&apos; + &apos;I&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_77776944" MODIFIED="1132333714746" TEXT="Es gibt keine Option zum Einbinden eigener Piktogramme. Sie k&#xf6;nnen nur aus dem Piktogrammangebot von FreeMind w&#xe4;hlen."/>
<node CREATED="1124560950717" ID="Freemind_Link_141235885" MODIFIED="1134580931220" TEXT="Um die Piktogrammleiste zu verstecken oder anzuzeigen, w&#xe4;hlen Sie im Kontextmen&#xfc; des Hauptfensterhintergrunds &apos;Werkzeugmen&#xfc; links ein/aus&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_291398994" MODIFIED="1132334106440" TEXT="Freemind stellt Ihnen unter anderen die Piktogramme&#xa; dieses Knotens zur Verf&#xfc;gung.">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1996597932" MODIFIED="1132425748381" POSITION="right" TEXT="Graphische Verweise hinzuf&#xfc;gen">
<node CREATED="1124560950717" ID="Freemind_Link_1579462759" MODIFIED="1132426029136" TEXT="Um einen graphischen Verweis zwischen zwei Knoten zu erzeugen, ziehen Sie mit gedr&#xfc;ckter, linker Maustaste einen Knoten auf einen anderen, w&#xe4;hrend Sie die Umschalt-Taste und die &apos;Strg&apos;-Taste gleichzeitig gedr&#xfc;ckt halten. Beachten Sie, da&#xdf; Sie am Ziel die Maustaste vor den Tasten Umschalt und &apos;Strg&apos; loslassen.">
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="255;0;" ID="Freemind_Arrow_Link_1428344028" STARTARROW="None" STARTINCLINATION="255;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1041595722" MODIFIED="1132426134157" TEXT="Altenativ ziehen Sie den einen Knoten mit gedr&#xfc;ckter, rechter Maustaste auf den anderen."/>
<node CREATED="1124560950717" ID="_Freemind_Link_208378337" MODIFIED="1132426574713" TEXT="Um die Farbe des Verweises zu &#xe4;ndern, benutzen Sie das Kontextmen&#xfc; indem Sie mausrechts auf den graphischen Verweis klicken."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1484370636" MODIFIED="1134581184209" TEXT="Benutzen Sie ebenfalls das Kontextmen&#xfc;, um die Richtungspfeile des Verweises zu &#xe4;ndern"/>
<node CREATED="1124560950717" ID="Freemind_Link_239549374" MODIFIED="1134581191729" TEXT="oder um den Verweis zu l&#xf6;schen."/>
<node CREATED="1124560950717" ID="_Freemind_Link_266716332" MODIFIED="1132427011751" TEXT="Auch um zu einem der Endknoten des graphischen Verweises zu steuern, benutzen Sie das Kontextmen&#xfc;.">
<linktarget COLOR="#b0b0b0" DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="255;0;" ID="Freemind_Arrow_Link_1428344028" SOURCE="Freemind_Link_1579462759" STARTARROW="None" STARTINCLINATION="255;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="256;22;" ID="Freemind_Arrow_Link_1273596772" SOURCE="_Freemind_Link_1015289745" STARTARROW="None" STARTINCLINATION="244;32;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1015289745" MODIFIED="1132427405313" TEXT="Um Anlenkpunkt und Verlauf eines graphischen Verweises zu &#xe4;ndern, fassen Sie ihn mit der Maus (mauslinks gedr&#xfc;ckt halten) und bewegen ihn.">
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="256;22;" ID="Freemind_Arrow_Link_1273596772" STARTARROW="None" STARTINCLINATION="244;32;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_770378678" MODIFIED="1132427456631" TEXT="Ein Beispiel f&#xfc;r einen graphischen Verweis folgt:"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_933788911" MODIFIED="1132427470711" TEXT="Beispiel">
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1170112929" MODIFIED="1132427509251" TEXT="Verweis zu einem anderen Teil">
<arrowlink COLOR="#9999ff" DESTINATION="_Freemind_Link_1492563156" ENDARROW="Default" ENDINCLINATION="115;0;" ID="Freemind_Arrow_Link_33407992" STARTARROW="Default" STARTINCLINATION="30;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="_Freemind_Link_1170112929" ENDARROW="Default" ENDINCLINATION="61;0;" ID="Freemind_Arrow_Link_1872050149" SOURCE="_Freemind_Link_1370577235" STARTARROW="None" STARTINCLINATION="61;0;"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_313185549" MODIFIED="1132427537050" TEXT="Knoten mit eingefaltetem Unterknoten">
<node CREATED="1124560950717" ID="_Freemind_Link_1492563156" MODIFIED="1132427551243" TEXT="Unterknoten">
<linktarget COLOR="#9999ff" DESTINATION="_Freemind_Link_1492563156" ENDARROW="Default" ENDINCLINATION="115;0;" ID="Freemind_Arrow_Link_33407992" SOURCE="_Freemind_Link_1170112929" STARTARROW="Default" STARTINCLINATION="30;0;"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1370577235" MODIFIED="1132427580388" TEXT="Ein anderer Verweis">
<arrowlink DESTINATION="_Freemind_Link_1170112929" ENDARROW="Default" ENDINCLINATION="61;0;" ID="Freemind_Arrow_Link_1872050149" STARTARROW="None" STARTINCLINATION="61;0;"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_423038022" MODIFIED="1132427596388" POSITION="right" TEXT="Suchen">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_58565005" MODIFIED="1132427897162" TEXT="Um Text in einem Knoten und all seinen Unterknoten (Kinderknoten) zu finden, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;F&apos;.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1818129679" MODIFIED="1134581315660" TEXT="Um den n&#xe4;chster Treffer zum letzten Suchauftrag zu finden (Weitersuchen), dr&#xfc;cken Sie &apos;Strg&apos; + &apos;G&apos;.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_205223436" MODIFIED="1132428104350" TEXT="Um den kompletten Baum zu durchsuchen, w&#xe4;hlen Sie vor Ihrer Suche den zentralen Knoten des Baums indem Sie &apos;Esc&apos; dr&#xfc;cken."/>
<node CREATED="1124560950717" ID="Freemind_Link_599030968" MODIFIED="1132428696821" TEXT="Die Suche l&#xe4;uft nach einem breitenorientierten Suchverfahren ab. Dies entspricht der Idee, da&#xdf;, je tiefer ein Knoten liegt, umso Detaillierteres dort beschrieben ist."/>
<node CREATED="1124560950717" ID="Freemind_Link_484869271" MODIFIED="1132428230385" TEXT="Bedenken Sie, da&#xdf; stets nur der aktuell gew&#xe4;hlte Knoten und seine Unterknoten durchsucht werden."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_653540280" MODIFIED="1132500713438" POSITION="right" TEXT="Mehrere Knoten markieren">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_122913446" MODIFIED="1132500731228" TEXT="Um mehrere Knoten gleichzeitig zu markieren, halten Sie die &apos;Strg&apos;-Taste oder die Umschalt-Taste gedr&#xfc;ckt, w&#xe4;hrend Sie auf einen Knoten klicken. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1602740822" MODIFIED="1132500772379" TEXT="Um den bereits markierten Knoten weitere hinzuzuf&#xfc;gen, halten Sie die &apos;Strg&apos;-Taste gedr&#xfc;ckt, w&#xe4;hrend Sie auf die zus&#xe4;tzlich zu markierenden Knoten klicken.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_42219870" MODIFIED="1132500800596" TEXT="Um eine fortlaufende Reihe Knoten zu markieren, halten Sie beim Klicken die Umschalt-Taste gedr&#xfc;ckt, oder Sie halten die Umschalt-Taste gedr&#xfc;ckt und bewegen sich mit den Pfeil-Tasten (Cursor-Tasten) im Baum.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1517301568" MODIFIED="1134581626822" TEXT="Um einen kompletten Unterbaum zu markieren, halten Sie die &apos;Alt&apos;-Taste gedr&#xfc;ckt, w&#xe4;hrend Sie Klicken. Oder Sie halten die Umschalt-Taste gedr&#xfc;ckt, w&#xe4;hrend Sie sich mit den Pfeil-Tasten von einem Knoten zu seinem Elternknoten bewegen."/>
<node CREATED="1124560950717" ID="Freemind_Link_1762513974" MODIFIED="1132500861250" TEXT="Um die Markierung mehrerer Knoten aufzuheben, klicken Sie in den Fensterhintergrund oder auf einen nicht markierten Knoten."/>
<node CREATED="1124560950717" ID="Freemind_Link_1915988288" MODIFIED="1132501038937" TEXT="Um alle sichtbaren Knoten zu markieren, w&#xe4;hlen Sie im Hauptmen&#xfc; &apos;Bearbeiten&apos; den Punkt &apos;Alles markieren&apos;, oder Sie dr&#xfc;cken die Tastenkombination &apos;Strg&apos; + &apos;A&apos;."/>
<node CREATED="1124560950717" ID="Freemind_Link_476976996" MODIFIED="1132501085329" TEXT="Um alle sichtbaren Knoten eines Zweiges zu markieren, w&#xe4;hlen Sie im Hauptmen&#xfc; &apos;Bearbeiten&apos; den Punkt &apos;Zweig markieren&apos;, oder Sie dr&#xfc;cken die Tastenkombination &apos;Strg&apos; + Umschalt + &apos;A&apos;."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1024903226" MODIFIED="1132503532023" POSITION="right" TEXT="Drag and drop - Ziehen und Fallenlassen">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1132503542344" ID="Freemind_Link_159607929" MODIFIED="1134581777933" TEXT="--------&#xa;Anm.d.&#xdc;.&#xa;Drag and Drop bedeutet: Mit gedr&#xfc;ckter Maustaste - in der Regel die linke - etwas aufzunehmen, zum gew&#xfc;nschten Ziel zu ziehen und es dort durch Loslassen der Maustaste fallen zu lassen."/>
<node CREATED="1124560950717" ID="Freemind_Link_1497093408" MODIFIED="1132501904228" TEXT="Durch Ziehen und Fallenlassen (drag and drop) k&#xf6;nnen Sie Knoten im Baum neu positionieren.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_374323949" MODIFIED="1132507949251" TEXT="Um einen aufgenommenen Knoten als Unterknoten wieder einzuf&#xfc;gen, positionieren Sie den Mauszeiger im seitlichen Randbereich des k&#xfc;nftigen Elternknotens und lassen die Maustaste los.&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;Achten Sie beim Positionieren auf die Farbverlaufs&#xe4;nderungen. Zum Einf&#xfc;gen als Unterknoten mu&#xdf; der in entgegengesetzter Richtung zur Baumwurzel befindliche seitliche Bereich des k&#xfc;nftigen Elternknotens durch Farbverlauf unterlegt sein. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1069770199" MODIFIED="1132502845874" TEXT="Um einen aufgenommenen Knoten als Geschwisterknoten einzuf&#xfc;gen, positionieren Sie den Mauszeiger im oberen Bereich des Zielknotens und lassen die Maustaste los.&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;Achten Sie beim Positionieren auch hier auf die Farbverlaufs&#xe4;nderungen. Zum Einf&#xfc;gen als Geschwisterknoten mu&#xdf; der obere Bereich des angesteuerten Zielknotens durch Farbverlauf unterlegt sein. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1628702212" MODIFIED="1134582094975" TEXT="Um eine vorhandene MindMap zu bearbeiten, nehmen Sie die MaindMap-Datei mit der Maus auf, ziehen die Datei in das FreeMind-Hauptfenster und lassen die Maustaste los. Dies funktioniert in Microsoft Windows und anderen Betriebssystemen mit daf&#xfc;r eingerichteten Benutzerschnittstellen."/>
<node CREATED="1124560950717" ID="Freemind_Link_1940236238" MODIFIED="1132503272668" TEXT="Um einen graphischen Verweis zwischen zwei Knoten zu erzeugen, ziehen Sie den einen Knoten mit gedr&#xfc;ckter rechter Maustaste auf den anderen und lassen ihn dort fallen."/>
<node CREATED="1124560950717" ID="Freemind_Link_849732842" MODIFIED="1132504132603" TEXT="Wenn Sie mehrere Knoten markiert haben, werden alle bewegt bzw. kopiert.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_873938281" MODIFIED="1134582225689" TEXT="FreeMind unterst&#xfc;tzt allgemein (je nach genutzter Betriebssystemplattform) die Daten&#xfc;bernahme aus externen Programmen durch den drag-and-drop Machanismus, z. B. Dateien unter Microsoft Windows oder markierten Text von einer besuchten Internetseite. "/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_958781924" MODIFIED="1132504553246" POSITION="right" TEXT="Kopieren und Einf&#xfc;gen">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1005190166" MODIFIED="1132505493929" TEXT="Wie erwartet, k&#xf6;nnen Sie Knoten(gruppen) zwischen MindMaps kopieren und einf&#xfc;gen. Dar&#xfc;berhinaus ist es m&#xf6;glich, normalen Text oder HTML-Code aus anderen Programmen einzuf&#xfc;gen.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_969081683" MODIFIED="1132505324689" TEXT="Wenn Sie einfachen Text einf&#xfc;gen, werden mehrere Zeilen als mehrere Knoten eingef&#xfc;gt, wobei die resultierende Schachteltiefe durch die Anzahl f&#xfc;hrender Leerzeichen der einzuf&#xfc;genden Textzeilen bestimmt wird. Ein Beispiel folgt: "/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_1681138405" MODIFIED="1132505347214" TEXT="Baum&#xa;     Eiche&#xa;     Buche&#xa;     ">
<node CREATED="1124560950717" ID="Freemind_Link_1554374196" MODIFIED="1132505362841" TEXT="wird eingef&#xfc;gt als">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_655988402" MODIFIED="1132505369279" TEXT="Baum">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_397183524" MODIFIED="1132505384189" TEXT="Eiche">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_443099731" MODIFIED="1132505377442" TEXT="Buche">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1398775173" MODIFIED="1132505815604" TEXT="Wenn Sie HTML-Code einf&#xfc;gen, wird er als reiner Text eingef&#xfc;gt. Au&#xdf;erdem werden die im HTML-Code eingebetteten Verweise als Unterknoten eines zus&#xe4;tzlich erstellten Geschwisterknotens mit dem Text &quot;Links&apos; eingef&#xfc;gt und korrekt verschaltet. Wieder folgt ein Beispiel:"/>
<node CREATED="1124560950717" ID="Freemind_Link_1302692231" MODIFIED="1132505868689" TEXT="Beispielresultat nach dem Einf&#xfc;gen:">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Shopping (120236)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Urban Living (19)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1087432743" MODIFIED="1124560950717" TEXT="Links">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" LINK="http://directory.google.com/Top/Shopping/" MODIFIED="1124560950717" TEXT="Shopping">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" LINK="http://directory.google.com/Top/Home/Urban_Living/" MODIFIED="1124560950717" TEXT="Urban Living">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1647505590" MODIFIED="1132506085846" TEXT="Wenn Sie eine im Explorer von Microsoft Windows markierte Dateiliste einf&#xfc;gen, wird diese als ein Satz von Verweisen auf die Dateien eingef&#xfc;gt."/>
<node CREATED="1124560950717" ID="Freemind_Link_1162068016" MODIFIED="1132506892736" TEXT="Wenn Sie in FreeMind einen Ast kopieren und ihn in einen einfachen Texteditor einf&#xfc;gen, wird die Baumstruktur durch Einr&#xfc;cken angezeigt. Querverweise werden in spitzen Klammern (&apos;&lt;&apos; und &apos;&gt;&apos;) eingef&#xfc;gt. Auch hier ein Beispiel:"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_468964192" MODIFIED="1132506358783" TEXT="Baum">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_290281774" MODIFIED="1132506365949" TEXT="Eiche">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_783362010" MODIFIED="1132506372866" TEXT="Buche">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1836799409" MODIFIED="1132506388184" TEXT="wird eingef&#xfc;gt als">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_1113784744" MODIFIED="1132506410017" TEXT="Baum&#xa;     Eiche&#xa;     Buche&#xa;     Google &lt;http://www.google.com/&gt;&#xa;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950732" LINK="http://www.google.com/" MODIFIED="1124560950732" TEXT="Google">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1886459567" MODIFIED="1132507230345" TEXT="Wenn Sie einen Zweig aus FreeMind kopieren und f&#xfc;gen ihn in eine Textverarbeitung ein, die das Rich-Text-Format (RTF) beherrscht, wird die Formatierung enschlie&#xdf;lich Farbe und Schrift mit &#xfc;bernommen. Querverweise werden in spitzen Klammern (&apos;&lt;&apos; und &apos;&gt;&apos;) eingef&#xfc;gt, genau wie beim Einf&#xfc;gen in einen einfachen Texteditor. Editoren die das Rich-Text-Format (RTF) beherrschen sind zum Beispiel Microsoft Word, OpenOffice.org, Microsoft Outlook und vergleichbare Programme unter LINUX. "/>
<node CREATED="1124560950732" ID="Freemind_Link_533970740" MODIFIED="1132507492906" TEXT="Um einen Knoten ohne Unterknoten zu kopieren, dr&#xfc;cken Sie die Tastenkombination &apos;Strg&apos; + Umschalt + &apos;C&apos; oder benutzen Sie &apos;Einfach kopieren&apos; im Kontextmen&#xfc; des Knotens."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="_Freemind_Link_1540212684" MODIFIED="1132507651785" POSITION="right" TEXT="Sich im Baum bewegen">
<node CREATED="1124560950732" ID="Freemind_Link_1039715110" MODIFIED="1132507751847" TEXT="Um den Focus nach oben, unten, links oder rechts zu bewegen, benutzen Sie die Pfeil-Tasten (Cursor-Tasten)."/>
<node CREATED="1124560950732" ID="Freemind_Link_629214166" MODIFIED="1134583224160" TEXT="Um zum Anfang des aktuellen Teilbaums zu gelangen, dr&#xfc;cken Sie die Bild-aufw&#xe4;rts-Taste."/>
<node CREATED="1124560950732" ID="Freemind_Link_940904871" MODIFIED="1134583239307" TEXT="Um zum Ende des aktuellen Teilbaums zu gelangen, dr&#xfc;cken Sie die Bild-abw&#xe4;rts-Taste."/>
<node CREATED="1124560950732" ID="Freemind_Link_261166838" MODIFIED="1132508319640" TEXT="Um zum Wuzelknoten des gesamten Baums zu gelangen, dr&#xfc;cken Sie &apos;Esc&apos;."/>
<node CREATED="1124560950732" ID="_Freemind_Link_97763226" MODIFIED="1132508561067" TEXT="Um einen Knoten frei zu positionieren, packen Sie ihn an seinem unsichtbaren, seitlich in Richtung Baumwurzel gelegenen Griff und bewegen ihn."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_4727471" MODIFIED="1132508582202" POSITION="right" TEXT="Falten und Entfalten">
<node CREATED="1124560950732" ID="Freemind_Link_1498138240" MODIFIED="1132508703102" TEXT="Um einen Knoten zu falten, dr&#xfc;cken Sie die Leer-Taste, oder w&#xe4;hlen Sie &apos;Knoten falten/entfalten&apos; in seinem Kontextmen&#xfc;."/>
<node CREATED="1124560950732" ID="Freemind_Link_1235309171" MODIFIED="1132508827501" TEXT="Um einen Knoten zu entfalten, dr&#xfc;cken Sie die Leer-Taste, w&#xe4;hlen Sie &apos;Konten falten/entfalten&apos; in seinem Kontextmen&#xfc; oder dr&#xfc;cken Sie die in Richtung des Entfaltens weisende Pfeil-Taste."/>
<node CREATED="1124560950732" ID="Freemind_Link_1372375256" MODIFIED="1132509382793" TEXT="Um Knoten in Ebenen zu falten und zu entfalten, halten Sie die &apos;Alt&apos;-Taste gedr&#xfc;ckt, w&#xe4;hrend Sie am Mausrad drehen oder Sie benutzen die Tastenkombinationen &apos;Alt&apos; + Bild-aufw&#xe4;rts und &apos;Alt&apos; + Bild-abw&#xe4;rts. Benutzen Sie diese Funktion mit gro&#xdf;en MindMaps vorsichtig, sie kann zu Problemen wegen zu geringem Arbeitsspeicher f&#xfc;hren."/>
<node CREATED="1124560950732" ID="Freemind_Link_1585400042" MODIFIED="1132509626634" TEXT="Um alles zu entfalten, klicken Sie auf den grauen Plus-Knopf in der Hauptwerkzeugleiste, w&#xe4;hlen Sie im Hauptmen&#xfc; &apos;Navigieren&apos; den Eintrag  &apos;Alles aufklappen&apos; oder nutzen Sie die Tastenkombination &apos;Alt&apos; + &apos;Ende&apos;."/>
<node CREATED="1124560950732" ID="Freemind_Link_473478105" MODIFIED="1132509776462" TEXT="Um alles zu falten, klicken Sie auf den grauen Minus-Knopf in der Hauptwerkzeugleiste, w&#xe4;hlen Sie im Hauptmen&#xfc; &apos;Navigieren&apos; den Eintrag &apos;Alles zuklappen&apos; oder nutzen Sie die Tastenkombination &apos;Alt&apos; + &apos;Pos1&apos;."/>
<node CREATED="1124560950732" ID="Freemind_Link_1346748802" MODIFIED="1132509901520" TEXT="Ein gefalteter (zugeklappter) Knoten ist durch einen kleinen Kreis am nach au&#xdf;en weisenden Ende gekennzeichnet."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_516331171" MODIFIED="1132509945232" POSITION="right" TEXT="Zu einer anderen MindMap wechseln">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_518659766" MODIFIED="1132510069794" TEXT="Um zu einer anderen, bereits ge&#xf6;ffneten MindMap zu wechseln, klicken Sie mausrechts in den Fensterhintergrund und w&#xe4;hlen die gew&#xfc;nschte MindMap aus dem Kontextmen&#xfc;. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_467411537" MODIFIED="1132510763453" POSITION="right" TEXT="Die MindMap verschieben">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1566079453" MODIFIED="1132511112504" TEXT="Um die Mindmap im Fenster zu verschieben, klicken Sie mauslinks in den Fensterhintergrund und bewegen Sie die Maus bei gedr&#xfc;ckter Taste. Um die Mindmap vertikal im Fenster zu rollen, benutzen Sie das Mausrad; zum horizontalen Rollen halten Sie dazu noch eine Maustaste oder die Umschalt-Taste gedr&#xfc;ckt.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913137192" MODIFIED="1132511609587" POSITION="right" TEXT="Ma&#xdf;stab &#xe4;ndern">
<node CREATED="1124560950732" ID="Freemind_Link_199998612" MODIFIED="1132511564154" TEXT="Zum Vergr&#xf6;&#xdf;ern bzw. Verkleinern der Baumansicht drehen Sie das Mausrad bei gedr&#xfc;ckter &apos;Strg&apos;-Taste oder benutzen die Tastenkombinationen &apos;Alt&apos; + Pfeil-aufw&#xe4;rts und &apos;Alt&apos; + Pfeil-abw&#xe4;rts. Alternativ k&#xf6;nnen Sie auch vom Ma&#xdf;stab-Aufklappmen&#xfc; in der Hauptwerkzeugleiste Gebrauch machen."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1318678369" MODIFIED="1132511646939" POSITION="right" TEXT="R&#xfc;ckg&#xe4;ngig machen">
<node CREATED="1124560950732" ID="Freemind_Link_494136549" MODIFIED="1132511831073" TEXT="Um Ihre letzte Bearbeitung r&#xfc;ckg&#xe4;ngig zu machen, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;Z&apos; oder w&#xe4;hlen Sie &apos;R&#xfc;ckg&#xe4;ngig&apos; im Hauptmen&#xfc; &apos;Bearbeiten&apos;."/>
<node CREATED="1124560950732" ID="Freemind_Link_1593613130" MODIFIED="1132511919933" TEXT="Um r&#xfc;ckg&#xe4;ngig Gemachtes wiederherzustellen, dr&#xfc;cken Sie &apos;Strg&apos; + &apos;Y&apos; oder w&#xe4;hlen Sie &apos;Wiederherstellen&apos; im Hauptmen&#xfc; &apos;Bearbeiten&apos;."/>
<node CREATED="1124560950732" ID="Freemind_Link_1397680495" MODIFIED="1132512579234" TEXT="Um die Anzahl der m&#xf6;glichen Schritte des R&#xfc;ckg&#xe4;ngigmachens festzulegen, rufen Sie &#xfc;ber das Hauptmen&#xfc; &apos;Extras&apos; die Dialogbox &apos;Einstellungen...&apos; auf und tragen dort in der Abteilung &apos;Verhalten&apos; bei &apos;Anzahl widerrufbarer Schritte&apos; den gew&#xfc;nschten Wert ein."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_22510332" MODIFIED="1132513247596" POSITION="right" TEXT="Export nach HTML">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1166599938" MODIFIED="1134585346868" TEXT="Um einen Zweig ins HTML-Format zu exportieren, benutzen Sie die Tastenkombination &apos;Strg&apos; + &apos;H&apos;. Exportierte HTML-Seiten k&#xf6;nnen abh&#xe4;ngig von den getroffenen Einstellungen in der &apos;Einstellungen...&apos;-Dialogbox Faltung unterst&#xfc;tzen. ">
<linktarget COLOR="#b0b0b0" DESTINATION="Freemind_Link_1166599938" ENDARROW="Default" ENDINCLINATION="439;0;" ID="Freemind_Arrow_Link_29973473" SOURCE="Freemind_Link_1307576694" STARTARROW="None" STARTINCLINATION="439;0;"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_515245049" MODIFIED="1132512917913" TEXT="Um eine andere Export-Funktion zu nutzen, w&#xe4;hlen Sie im Hauptmen&#xfc; &apos;Datei&apos; &#xfc;ber den Punkt &apos;Export&apos; die gew&#xfc;nschte Funktion, z. B. &apos;Als XHTML (JavaScript Version)...&apos;."/>
<node CREATED="1124560950732" ID="Freemind_Link_319123418" MODIFIED="1132513214820" TEXT="Um eine MindMap mit einem klickbaren &#xdc;bersichtsbild nach HTML zu exportieren, w&#xe4;hlen Sie &#xfc;ber &apos;Export&apos; im Hauptmen&#xfc; &apos;Datei&apos; den Eintrag &apos;Als XHTML (mit verlinktem Bild der MindMap)...&apos;."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1908686168" MODIFIED="1132513365718" POSITION="right" TEXT="Exportieren als Pixel- oder Vektorgraphik">
<node CREATED="1124560950732" ID="Freemind_Link_171602439" MODIFIED="1132513499695" TEXT="Um die MindMap als PNG-Bild zu exportieren, w&#xe4;hlen Sie vom Hauptmen&#xfc; ausgehend &apos;Datei&apos; -&gt; &apos;Export&apos; -&gt; &apos;Als PNG...&apos;."/>
<node CREATED="1124560950732" ID="Freemind_Link_551123456" MODIFIED="1132513535036" TEXT="Um die MindMap als JPEG-Bild zu exportieren, w&#xe4;hlen Sie vom Hauptmen&#xfc; ausgehend &apos;Datei&apos; -&gt; &apos;Export&apos; -&gt; &apos;Als JPEG...&apos;."/>
<node CREATED="1124560950732" ID="Freemind_Link_575443583" MODIFIED="1132513625402" TEXT="Um die MindMap als SVG zu exportieren, w&#xe4;hlen Sie vom Hauptmen&#xfc; ausgehend &apos;Datei&apos; -&gt; &apos;Export&apos; -&gt; &apos;Als SVG...&apos;. Diese Funktion ist nur verf&#xfc;gbar, wenn Sie die SVG-Erweiterung installiert haben."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_329770204" MODIFIED="1132513664175" POSITION="right" TEXT="Exportieren in andere XML-Formate">
<node CREATED="1124560950732" ID="Freemind_Link_641809362" MODIFIED="1132514511240" TEXT="Um die MindMap in ein anderes XML-Format zu exportieren, f&#xfc;r das Sie &#xfc;ber eine XSL-Datei verf&#xfc;gen, w&#xe4;hlen Sie vom Hauptmen&#xfc; ausgehend &apos;Datei&apos; -&gt; &apos;Export&apos; -&gt; &apos;Mittels XSLT...&apos;."/>
<node CREATED="1124560950732" ID="Freemind_Link_958818637" MODIFIED="1132514449141" TEXT="Um die MindMap in eine OpenOffice1.4Writer-Datei (SXW-Format) zu exportieren, w&#xe4;hlen Sie vom Hauptmen&#xfc; ausgehend &apos;Datei&apos; -&gt; &apos;Export&apos; -&gt; &apos;Als OpenOffice Writer Dokument...&apos;."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1841136119" MODIFIED="1132515107600" POSITION="right" TEXT="Verzeichnisstruktur importieren">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_561962043" MODIFIED="1132515095477" TEXT="Um eine Verzeichnisstruktur zu importieren, w&#xe4;hlen Sie vom Hauptmen&#xfc; ausgehend &apos;Datei&apos; -&gt; &apos;Import&apos; -&gt; &apos;Ordnerstruktur...&apos;. Sie werden nach dem Verzeichnis gefragt, dessen Struktur Sie importieren wollen. Mit Struktur meinen wir den Baum aller (nicht notwendigerweise direkter) Unterverzeichnisse mit den Verweisen auf die Dateien in diesen Unterverzeichnissen. Ein Beispiel f&#xfc;r so eine eingef&#xfc;gte Struktur folgt:&#xa;"/>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_1517632416" MODIFIED="1132515122814" TEXT="Beispiel">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_1374652558" MODIFIED="1132515147856" TEXT="Gew&#xe4;hlter Ordner">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1320387320" LINK="C:\Programme\Microsoft%20Office\Office\Bitmaps" MODIFIED="1134584600122" TEXT="C:\Programme\Microsoft Office\Office\Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1242662698" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/" MODIFIED="1124560950732" TEXT="Dbwiz">
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ASSETS.GIF" MODIFIED="1124560950732" TEXT="ASSETS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF" MODIFIED="1124560950732" TEXT="CONTACTS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF" MODIFIED="1124560950732" TEXT="EVTMGMT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF" MODIFIED="1124560950732" TEXT="EXPENSES.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF" MODIFIED="1124560950732" TEXT="INVENTRY.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/LEDGER.GIF" MODIFIED="1124560950732" TEXT="LEDGER.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF" MODIFIED="1124560950732" TEXT="ORDPROC.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF" MODIFIED="1124560950732" TEXT="RESOURCE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/SERVICE.GIF" MODIFIED="1124560950732" TEXT="SERVICE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF" MODIFIED="1124560950732" TEXT="TIMEBILL.GIF"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1127993679" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/" MODIFIED="1124560950732" TEXT="Styles">
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLENDS.GIF" MODIFIED="1124560950732" TEXT="ACBLENDS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLUPRT.GIF" MODIFIED="1124560950732" TEXT="ACBLUPRT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACEXPDTN.GIF" MODIFIED="1124560950732" TEXT="ACEXPDTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACINDSTR.GIF" MODIFIED="1124560950732" TEXT="ACINDSTR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACRICEPR.GIF" MODIFIED="1124560950732" TEXT="ACRICEPR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSNDSTN.GIF" MODIFIED="1124560950732" TEXT="ACSNDSTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSUMIPT.GIF" MODIFIED="1124560950732" TEXT="ACSUMIPT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_269203785" MODIFIED="1132515432243" POSITION="right" TEXT="Internet Explorer Favoriten importieren">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1567658129" MODIFIED="1150324250313">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    Um Internet Explorer Favoriten (Lesezeichen) in FreeMind zu importieren, w&#xe4;hlen Sie vom Hauptmen&#xfc; ausgehend 'Datei' -&gt; 'Import' -&gt; 'Explorer-Favoriten...'. Sie werden nach dem Pfad zu dem Verzeichnis gefragt, in dem die Favoriten abgelegt sind. Der Name des Verzeichnisses ist "Favoriten" und Sie finden es auf Ihrer Festplatte. F&#xfc;r ein unmodifiziertes, deutsches Windows 2000 lautet der vollst&#xe4;ndige Pfadname "C:\Dokumente und Einstellungen\&lt;Benutzername&gt;\Favoriten", wobei Sie '&lt;Benutzername&gt;' durch den tats&#xe4;chlich verwendeten Benutzernamen ersetzen.
  </body>
</html></richcontent>
</node>
<node COLOR="#999999" CREATED="1124560950732" MODIFIED="1124560950732" TEXT="Key words: Microsoft Internet Explorer, MSIE, MS IE.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1709974530" MODIFIED="1132516028510" POSITION="right" TEXT="MindManager X5 MindMap importieren">
<node CREATED="1124560950732" ID="Freemind_Link_1166749224" MODIFIED="1132516137707" TEXT="Um eine MindManager X5 MindMap zu importieren, w&#xe4;hlen Sie vom Hauptmen&#xfc;ausgehend &apos;Datei&apos; -&gt; &apos;Import&apos; -&gt; &apos;MindManager X5 Map...&apos;."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913645795" MODIFIED="1132516167194" POSITION="right" TEXT="Integration mit Word oder Outlook">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_855025503" MODIFIED="1134584823420" TEXT="Sie k&#xf6;nnen MindMaps oder Zweige von MindMaps in Microsoft Word, Wordpad oder in Outlook Nachrichten einf&#xfc;gen. Generell kann in jedes Anwendungsprogramm, das Rich-Text-Format (RTF) beherrscht, eingef&#xfc;gt werden. Die Textformatierung und die Verweise werden mit eingef&#xfc;gt.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_851316277" LINK="mailto:don.bonton@supermail.com" MODIFIED="1134585164247" TEXT="Klicken auf einen Verweis zu einer eMail-Adresse (z. B.: &apos;mailto:don.bonton@supermail.com&apos;)  &#xf6;ffnet Outlook um eine neue Nachricht zu verfassen, falls in Windows nicht anders eingestellt.&#xa;--------&#xa;Anm.d.&#xdc;.&#xa;Genauer: Falls das genutzte Betriebssystem diesen Mechanismus unterst&#xfc;tzt, wird das registrierte Programm zum Verfassen von eMails aufgerufen.">
<arrowlink DESTINATION="Freemind_Link_1897919343" ENDARROW="Default" ENDINCLINATION="740;0;" ID="Freemind_Arrow_Link_1804503188" STARTARROW="None" STARTINCLINATION="740;0;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_13384265" LINK="mailto:don.bonton@supermail.com?subject=Last%20phone%20call" MODIFIED="1134585213768" TEXT="Man kann beim Verweis auf eine eMail-Adresse gleich einen Betreff mit hinterlegen.">
<arrowlink DESTINATION="Freemind_Link_1054419207" ENDARROW="Default" ENDINCLINATION="722;0;" ID="Freemind_Arrow_Link_1534504502" STARTARROW="None" STARTINCLINATION="722;0;"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1307576694" MODIFIED="1134585346897" TEXT="Eine andere M&#xf6;glichkeit um MindMaps in Microsoft Word einzuf&#xfc;gen ist, sie unterteilt nach &#xdc;berschriften nach HTML zu exportieren, das HTML zu kopieren und es dann in Word einzuf&#xfc;gen.">
<arrowlink DESTINATION="Freemind_Link_1166599938" ENDARROW="Default" ENDINCLINATION="439;0;" ID="Freemind_Arrow_Link_29973473" STARTARROW="None" STARTINCLINATION="439;0;"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1822195277" MODIFIED="1132517115873" POSITION="right" TEXT="Voreinstellungen setzen">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1365597534" MODIFIED="1132517326745" TEXT="Um die Voreinstellungen zu bearbeiten, w&#xe4;hlen Sie vom Hauptmen&#xfc; ausgehend &apos;Extras&apos; -&gt; &apos;Einstellungen...&apos;. Die meisten &#xc4;nderungen greifen erst nach einem Neustart von FreeMind."/>
<node CREATED="1124560950732" ID="Freemind_Link_1271954958" MODIFIED="1132517721990" TEXT="Die Voreinstellungen schlie&#xdf;en die Tastaturk&#xfc;rzel, das Verhalten beim Exportieren nach HTML, die Art, wie die Anwahl von Knoten mit der Maus vorgenommen wird, die Schriftengl&#xe4;ttung und mehr ein."/>
<node COLOR="#999999" CREATED="1124560950732" ID="Freemind_Link_1035609976" MODIFIED="1132517147803" TEXT="Key words: customizing, anpassen.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1528828442" MODIFIED="1132517735721" POSITION="right" TEXT="Drucken">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_209487266" MODIFIED="1132518092944" TEXT="Sie k&#xf6;nnen entweder drucken, indem Sie die gesamte MindMap in eine Druckseite einpassen lassen oder indem Sie die MindMap auf mehrere Bl&#xe4;tter Papier verteilen lassen. Ihre Wahl nehmen Sie vom Hauptmen&#xfc; ausgehend unter &apos;Datei&apos; -&gt; &apos;Seiteneinrichtung...&apos; ff. vor."/>
<node CREATED="1124560950732" ID="Freemind_Link_911024183" MODIFIED="1132518210823" TEXT="Um den verf&#xfc;gbaren Platz wirtschaftlicher zu verwenden, w&#xe4;hlen Sie &apos;Querformat&apos; als Seiteneinstellung.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1573962506" MODIFIED="1132518767360" TEXT="Eine Druckvorschau der MindMap zu realisieren ist nicht ganz unkompliziert. Falls Sie &#xfc;ber einen Postscript-Drucker oder einen generischen Postscript-Druckertreiber verf&#xfc;gen, drucken Sie die Mindmap dar&#xfc;ber in eine Datei und betrachten Sie sie dann mit Ghostview oder einem &#xe4;hnlichen Programm. Wenn Sie versuchen, die MindMap mit einem nicht postscript-f&#xe4;higen Druckertreiber in eine Datei zu drucken, wird die resultierende Datei keinen Postscript-Code enthalten sondern vermutlich PCL-Code, welcher f&#xfc;r Sie unbrauchbar ist."/>
<node CREATED="1124560950732" ID="Freemind_Link_814459761" MODIFIED="1132519256852" TEXT="Sie k&#xf6;nnen auch von Ihrem Web-Browser aus drucken, nachdem Sie die MindMap nach HTML exportiert haben oder von Word oder Wordpad nachdem Sie die MindMap kopiert und dort wieder eingef&#xfc;gt haben. Au&#xdf;erdem k&#xf6;nnen Sie die MindMap nach HTML mit &#xdc;berschriften exportieren, sie dann kopieren, sie anschlie&#xdf;end in Microsoft Word einf&#xfc;gen und sie von dort aus drucken. Auf diese Art k&#xf6;nnen Sie Formatierungen &#xe4;ndern, wie Sie wollen.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_841140408" MODIFIED="1132519364643" POSITION="right" TEXT="Textattribute mittels HTML in Knoten verwenden">
<node CREATED="1124560950732" ID="Freemind_Link_1661237735" MODIFIED="1132519625819" TEXT="Knoten, die mit &apos;&lt;html&gt;&apos; beginnen, werden mit Hilfe des darin enthaltenen HTML-Codes erzeugt. Diese F&#xe4;higkeit ist f&#xfc;r technisch versierte Leute n&#xfc;tzlich. Ein Beispiel folgt:"/>
<node CREATED="1124560950732" ID="Freemind_Link_843632799" MODIFIED="1132520194964">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <h3>
      HTML Beispiel
    </h3>
    <p class="msonormal">
      Da sind verschiedene Punkte:
    </p>
    <ul type="disc">
      <li class="msonormal">
        Punkt eins
      </li>
      <li class="msonormal">
        Punkt zwei
      </li>
    </ul>
    <p class="msonormal">
      Und wir haben <b>Fettschrift</b> oder <i>Kursives</i>. <u>Unterstrichen</u>, ein <strike>Durchgestrichen</strike> auch.<br/><br/>Es gibt Tabellen:
    </p>
    <table style="border: none" border="1" class="msonormaltable" cellspacing="0" cellpadding="0">
      <tr>
        <td style="padding-bottom: .75pt; padding-right: .75pt; border: solid windowtext 1.0pt; padding-left: .75pt; padding-top: .75pt">
          <p class="msonormal">
            Zelle 1
          </p>
        </td>
        <td style="padding-bottom: .75pt; padding-right: .75pt; border: solid windowtext 1.0pt; border-left: none; padding-left: .75pt; padding-top: .75pt">
          <p class="msonormal">
            Zelle 2
          </p>
        </td>
      </tr>
      <tr>
        <td style="padding-bottom: .75pt; padding-right: .75pt; border-top: none; border: solid windowtext 1.0pt; padding-left: .75pt; padding-top: .75pt">
          <p class="msonormal">
            Zelle 3
          </p>
        </td>
        <td style="padding-bottom: .75pt; padding-right: .75pt; border-bottom: solid windowtext 1.0pt; border-top: none; border-left: none; border-right: solid windowtext 1.0pt; padding-left: .75pt; padding-top: .75pt">
          <p class="msonormal">
            Zelle 4
          </p>
        </td>
      </tr>
    </table>
    <p class="msonormal">
      <br/>
      &#xa0;Es gibt vielerlei <font color="#999900">Schrift</font><font color="#336600">farben</font>.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_233295626" MODIFIED="1132520708305" TEXT="Beim Export nach reinem Text oder RTF (f&#xfc;r Word, OpenOffice usw.) werden HTML-Knoten und Bilder nicht unterst&#xfc;tzt. Immerhin ist es praktisch, HTML zu benutzen, um mit Hilfe der FreeMind-Web-Anwendung im Internet zu publizieren.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_115696817" MODIFIED="1132526187660" POSITION="right" TEXT="Bilder in Knoten verwenden">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1821762263" MODIFIED="1132524451796" TEXT="Um ein Bild in FreeMind einzuf&#xfc;gen, dr&#xfc;cken Sie &apos;Alt&apos; + &apos;K&apos; oder benutzen Sie &apos;Einf&#xfc;gen&apos; -&gt; &apos;Bild (Dateiauswahl)...&apos; im Kontextmen&#xfc; des Knotens. Durch das Einf&#xfc;gen eines Bildes verlieren Sie den gesamten Knotentext, falls Sie vorher schon welchen eingegeben hatten. Auf diese Weise eingef&#xfc;gte Bilder werden au&#xdf;erhalb von FreeMind nicht korrekt eingebunden und vielleicht auch nicht korrekt nach HTML exportiert. Die Funktion, Bilder in FreeMind einzubinden, ist noch nicht ausgereift.  "/>
<node CREATED="1124560950732" ID="Freemind_Link_979830818" MODIFIED="1132524490682" TEXT="Unterst&#xfc;tzte Bilderformate sind PNG, JPEG und GIF."/>
<node CREATED="1124560950732" ID="Freemind_Link_1195889160" MODIFIED="1134586020640" TEXT="Um Verweise auf Bilder in sichtbare Bilder zu verwandeln, dr&#xfc;cken Sie &apos;Alt&apos; + &apos;K&apos;. Man kann mehrere Bilddateien in FreeMind ziehen (drag and drop), Sie wie mehrere Knoten markieren und Sie dann in sichtbare Bilder verwandeln, indem man &apos;Alt&apos; + &apos;K&apos; dr&#xfc;ckt."/>
<node COLOR="#000000" CREATED="1124560950732" ID="Freemind_Link_787833164" MODIFIED="1132525057251" TEXT="Eine mehr technische und nicht so benutzerfreundliche Art Bilder einzuf&#xfc;gen folgt hier: Es ist m&#xf6;glich, HTML in Knoten einzusetzen. Der Knoteninhalt mu&#xdf; mit der Kennzeichnung &apos;&lt;html&gt;&apos; beginnen. Auf diese Art kann man (dann mit HTML-Mitteln) Bilder in Knoten einbinden. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1068638398" MODIFIED="1132525090693" TEXT="Zum Beispiel&#xa;  &lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;&#xa;  &lt;html&gt;&lt;img src=&quot;file://C:/Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;&#xa;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1842376660" MODIFIED="1134586195001" TEXT="Man kann relative Verweise zur Bilderadressierung verwenden.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_489201373" MODIFIED="1132525208713" TEXT="Beispiele f&#xfc;r Bilder, die auf einigen Windows-Distributionen funktionieren">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1024263145" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_880988159" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="Freemind_Link_85163528" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF"/>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1804947546" MODIFIED="1132525274736" POSITION="right" TEXT="Experimentelle Dateisperrung verwenden">
<node CREATED="1124560950732" ID="Freemind_Link_1387969527" MODIFIED="1134586264056" TEXT="Die vorliegende Version von FreeMind verf&#xfc;gt &#xfc;ber einen experimentellen Mechanismus zum Sperren von Dateien, der in der Standardeinstellung ausgeschaltet ist. Die aktuelle Umsetzung beugt Verklemmungen nicht wirklich sicher vor, sollte aber f&#xfc;r die meisten praktischen Vorhaben ausreichen."/>
<node CREATED="1124560950732" ID="Freemind_Link_1350042783" MODIFIED="1134586322700" TEXT="Dateisperrung stellt sicher, da&#xdf; mehrere Anwender nicht zur selben Zeit die selbe MindMap bearbeiten. Dadurch wird gew&#xe4;hrleistet, da&#xdf; nicht der eine zuf&#xe4;llig die Bearbeitungen des anderen &#xfc;berschreibt (und damit l&#xf6;scht)."/>
<node CREATED="1124560950732" ID="Freemind_Link_151684674" MODIFIED="1134586368777" TEXT="Um die experimentelle Dateisperrung einzuschalten, gehen Sie in der vom Hauptmen&#xfc; aus &#xfc;ber &apos;Extras&apos; -&gt;  &apos;Einstellungen...&apos; erreichbaren Dialogbox in die Abteilung &apos;Umgebung&apos; und setzen dort den Schalter &apos;Experimentelles Sperren der ge&#xf6;ffneten Dateien&apos;."/>
</node>
<node COLOR="#407000" CREATED="1229414588553" FOLDED="true" ID="ID_1077619682" MODIFIED="1381609064330" POSITION="right" STYLE="fork" TEXT="Neue Funktionen in 0.9.0">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#407000" CREATED="1201283648829" FOLDED="true" ID="Freemind_Link_813308322" MODIFIED="1381609064323" STYLE="fork" TEXT="Neue Hauptfunktionen">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201283660674" ID="Freemind_Link_1390621915" MODIFIED="1381605909751" STYLE="fork" TEXT="Neuer Editor">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Der neue Editor unterst&#252;tzt Textformatierung in Knoten und Notizen (es handelt sich um das kleine Fenster am Fu&#223; des Fensters).
    </p>
    <p>
      Der Text wird direkt als HTML gespeichert und kann daher sehr effizient nach HTML exportiert werden.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1201283806888" ID="Freemind_Link_1546698647" MODIFIED="1381605979288" STYLE="fork" TEXT="Erweiterungen der Notizen">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Das Notizfenster geh&#246;rt nun zum Hauptfenster von FreeMind. Ein Tooltipp am Knoten zeigt zus&#228;tzlich die Notiz an.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1201506800600" ID="Freemind_Link_9416334" MODIFIED="1381606273912" STYLE="fork" TEXT="Filter">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Mit Filtern kann die aktuelle Mindmap nach vorgegebenen Kriterien reduziert werden. Wenn Sie z.B. nur die Knoten sehen wollen, die das Wort &quot;TODO&quot; enthalten, dann dr&#252;cken Sie bitte auf den Filterknopf (ein Trichtersymbol), die Filtertoolbar erscheint, w&#228;hlen Sie den Stift und f&#252;gen Sie das Kriterium hinzu. Danach w&#228;hlen Sie den Filter einfach in der Toolbar aus. Dementsprechend werden nur noch die gefilterten Knoten und alle ihre Vorg&#228;nger angezeigt bis Sie den Filter wieder ausschalten.
    </p>
    <p>
      Mit den Einstellungen &quot;Zeige Vorg&#228;nger&quot; und &quot;Zeige Nachfolger&quot; k&#246;nnen Sie die Anzeige der Vorg&#228;nger und Nachfolger beeinflussen.
    </p>
    <p>
      Es gibt unterschiedliche Kriterien. So k&#246;nnen Sie auch auf Icons und Attribute filtern.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1201506806036" ID="Freemind_Link_1096073845" MODIFIED="1381606385060" STYLE="fork" TEXT="Attribute">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Attribute sind zus&#228;tzliche Metainformationen in Form von Paaren von Schl&#252;sseln und Werten. Denkbar w&#228;re z.B. ein Attribut &quot;Kontext&quot;, dass die Werte &quot;Arbeit&quot; und &quot;Freizeit&quot; annimmt. Nach diesen Attributen kann gefiltert werden.
    </p>
    <p>
      Ferner werden aktuell Groovyskripte in Attributen gespeichert.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201282217311" FOLDED="true" ID="Freemind_Link_849247054" MODIFIED="1381609064324" STYLE="fork" TEXT="Ver&#xe4;nderung der Ansicht">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201282224869" ID="Freemind_Link_1307834035" MODIFIED="1381606430262" STYLE="fork" TEXT="MindMaps k&#xf6;nnen in Tabs ge&#xf6;ffnet werden">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Damit kann man auf einen Blick alle ge&#246;ffneten Maps sehen.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1201282406968" ID="Freemind_Link_101409050" MODIFIED="1381606444590" STYLE="fork" TEXT="Die Toolbar mit den Icons kann gescrollt werden">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201282319118" FOLDED="true" ID="Freemind_Link_1043646949" MODIFIED="1381609064327" STYLE="fork" TEXT="Verbesserung der Benutzbarkeit">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201282325640" FOLDED="true" ID="Freemind_Link_556186325" MODIFIED="1381609064326" STYLE="fork" TEXT="Knoten k&#xf6;nnen in alle Richtungen bewegt werden">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1201282465994" ID="Freemind_Link_924709284" MODIFIED="1381606489732" TEXT="Auf- und Abw&#xe4;rts">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Dies war schon in den Vorg&#228;ngerversionen enthalten.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1201282426565" FOLDED="true" ID="Freemind_Link_481786702" MODIFIED="1381609064324" TEXT="Links und Rechts">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Es ist nun auch m&#246;glich, Knoten nach rechts und links zu verschieben. Damit entfernen oder n&#228;hern sie sich dem Hauptknoten. Die Knoten k&#246;nnen sogar die Seite des Hauptknotens wechseln. Standardm&#228;&#223;ig k&#246;nnen Sie die Knoten mit Steuerung Links und Rechts bewegen.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1201282851749" ID="Freemind_Link_774463025" MODIFIED="1381606600211" TEXT="Ver&#xe4;nderung der Position in der Hierarchie"/>
<node COLOR="#111111" CREATED="1201282843249" ID="Freemind_Link_1554785271" MODIFIED="1381606612119" TEXT="Wechseln der Seite zum Hauptknoten"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201282332144" ID="Freemind_Link_536412761" MODIFIED="1381606630741" STYLE="fork" TEXT="Men&#xfc;punkte k&#xf6;nnen schnell mit Tastenkombinationen erreicht werden">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1202399993070" ID="Freemind_Link_860723289" MODIFIED="1381606655116" STYLE="fork" TEXT="Alle Formatierungen k&#xf6;nnen in einem einzigen Fenster vorgenommen werden">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1202400125364" ID="Freemind_Link_1848794893" MODIFIED="1381607178524" STYLE="fork" TEXT="Neuer Stil-Editor">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Stile sind sehr hilfreiche Helfer um ein konsistentes Layout zu erreichen. Mehrere Format&#228;nderungen k&#246;nnen so per Knopfdruck erfolgen. Der neue Stileditor kann mit F11 ge&#246;ffnet werden und zeigt alle vorhandenen Stile an.
    </p>
    <p>
      Es gibt die folgenden grundlegenden Funktionen:
    </p>
    <ul>
      <li>
        Mittels Drag&amp;Drop k&#246;nnen Sie Stile nach oben bzw. unten bewegen.
      </li>
      <li>
        Sie k&#246;nnen neue Stile mittels des &quot;Aktionen&quot; Men&#252;s hinzuf&#252;gen.
      </li>
      <li>
        Sie k&#246;nnen neue Stil auch von dem Format der ausgew&#228;hlten Knoten ableiten lassen. Wenn nur ein Knoten selektiert ist, so wird dessen Formatierung in einen neuen Stil &#252;bernommen. Bei mehreren selektierten Knoten werden nur die Formatelemente &#252;bernommen, die bei allen gleich sind.
      </li>
      <li>
        Sie k&#246;nnen Stile auf die selektierten Knoten anwenden und
      </li>
      <li>
        Sie k&#246;nnen Stile entfernen.
      </li>
    </ul>
    <p>
      Die Stile werden in der Datei patterns.xml im &lt;Heimverzeichnis&gt;/.freemind/ gespeichert und bei jedem Start von FreeMind geladen. Die Stile geh&#246;ren damit nicht zu einzelnen Mindmaps.
    </p>
    <p>
      Die Stile bestehen aus einer Reihe von Formatangaben mit einer Box, die die Symbole Plus, Minus und Leer enthalten kann. Dies bedeutet das folgende:
    </p>
    <ul>
      <li>
        Plus: die Format&#228;nderung wird ausgef&#252;hrt.
      </li>
      <li>
        Minus: dies Format wird auf den Standardwert zur&#252;ckgesetzt, also entfernt.
      </li>
      <li>
        Leer: die Formatierung wird nicht ver&#228;ndert.
      </li>
    </ul>
    <p>
      Als eine wichtige Neuerung ist es nun m&#246;glich, einem Stil auch ein zus&#228;tzliches Skript zuzuweisen. Damit sind die denkbaren &#196;nderungen sehr viel reichhaltiger m&#246;glich. Damit lassen sich sehr einfach Makros und Erweiterungen von FreeMind realisieren!
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1203059325942" ID="Freemind_Link_1489168699" MODIFIED="1381607374918" STYLE="fork" TEXT="Anpassbares Automatisches Layout">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      In den Einstellungen gibt es die M&#246;glichkeit, das Layout f&#252;r das &quot;Automatische Layout&quot; zu &#228;ndern.
    </p>
    <p>
      Diese &#196;nderungen wirken sich allerdings nicht direkt auf die Mindmap aus. Dazu m&#252;ssen Sie die Map erstmal schlie&#223;en und wieder &#246;ffnen. Die Einstellungen werden nicht in der Map gespeichert, sondern f&#252;r den Benutzer auf dem Rechner. Damit kann das &quot;Automatische Layout&quot; auf anderen Rechnern unterschiedlich aussehen. Dies wird in einer der n&#228;chsten Versionen von FreeMind ge&#228;ndert.
    </p>
    <p>
      Fortgeschrittene Benutzer k&#246;nnen auch die Anzahl von Ebenen ver&#228;ndern.&#160; Dazu mu&#223; allerdings die Datei &quot;auto.properties&quot; per Hand ge&#228;ndert werden.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1202400209358" ID="Freemind_Link_60926823" MODIFIED="1381607872964" STYLE="fork" TEXT="Suchen&amp;Ersetzen">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ein neuer &quot;Suchen und Ersetzen&quot; Dialog erm&#246;glicht ein sehr schnelles Suchen und erstmals auch ein automatisiertes Ersetzen.
    </p>
    <ul>
      <li>
        Bei Eingabe wird bereits losgesucht, auch die Notizen der mitdurchsucht.
      </li>
      <li>
        Die Ergebnisliste kann sortiert werden, sogar nach den Icons. Mittels der Zeitangaben kann die Historie der Map nachvollzogen werden!
      </li>
      <li>
        Mit dem Cursor kann man schnell zur Liste gelangen. Einfach zweimal nach &quot;Unten&quot; dr&#252;cken.
      </li>
      <li>
        Bei ausgew&#228;hltem Knoten wird dessen Pfad zum Hauptknoten angezeigt.
      </li>
      <li>
        Bei Ausw&#228;hlen eines Knotens mit der Eingabetaste wird direkt zu ihm gesprungen.
      </li>
      <li>
        Ersetzen: Sie k&#246;nnen ausw&#228;hlen ob in allen oder nur den ausgew&#228;hlten Knoten ersetzt werden soll.
      </li>
      <li>
        Export: dies ist eine sehr n&#252;tzliche Neuerung. Ein Satz von Knoten kann damit in eine neue Mindmap exportiert werden. Damit k&#246;nnen z.B. sehr einfach Todo-Listen erzeugt werden. Dazu sortieren Sie einfach nach den Icons, und w&#228;hlen die mit Ihrem Symbol f&#252;r &quot;Noch-Zu-Tun&quot; aus. Mit dem Export haben Sie davon sofort eine (flache) Liste.
      </li>
    </ul>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1208893265045" ID="ID_224953554" MODIFIED="1381608026674" STYLE="fork" TEXT="Icons">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Mittels Tastenkombinationen k&#246;nnen Sie nun noch einfacher die Icons verwalten. Bei gleichzeitig gehaltener Umschalttaste werden alle anderen Icons, die vorher zu einem Knoten geh&#246;rten, entfernt. Dies ist zum Beispiel bei den Zahlen n&#252;tzlich.
    </p>
    <p>
      Bei gehaltener Steuerungstaste wird das ausgew&#228;hlte Icon vom Knoten entfernt (wenn es mehrfach vorkommt, dann wird jeweils das letzte entfernt). Dies geschieht unabh&#228;ngig von den anderen Icons, die vorhanden sein k&#246;nnen.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201282939150" FOLDED="true" ID="Freemind_Link_150258579" MODIFIED="1381609064328" STYLE="fork" TEXT="Neue Exports">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201282945124" ID="Freemind_Link_1356291624" MODIFIED="1381608136085" STYLE="fork" TEXT="Als Flash und als Applet">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Flash and Java bringen Mindmaps ins internet.
    </p>
    <p>
      Dabei sieht das Applet genau wie in FreeMind aus, braucht allerdings l&#228;nger, um geladen zu werden. Der Flashexport sieht etwas anders aus, hat allerdings einige Zusatzfeatures.
    </p>
    <p>
      
    </p>
    <p>
      <b>Durch die gehobenen Sicherheitsstandards funktionieren diese Exporte zum Teil nur, wenn die Maps wirklich auf einem Webserver liegen.</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201506466515" FOLDED="true" ID="Freemind_Link_676471791" MODIFIED="1381609064329" STYLE="fork" TEXT="Skriptunterst&#xfc;tzung (engl.)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind can now be scripted by using Groovy scripts. Groovy is a very easy to use scripting language best integrating into FreeMind.
    </p>
    <p>
      There are two possibilities to use scripts:
    </p>
    <ol>
      <li>
        Choose the script editor to easily add, change and test your scripts. Technically, scripts are attached to a node via an attribute starting with "script" (like "script1") that contains the script. Every time you choose "Evaluate" from the tools menu, all scripts attached to nodes are executed.
      </li>
      <li>
        Create or change a pattern and press the script button. The script editor appears and your script will be associated to a pattern. Every time you apply the pattern to some nodes, the script is executed for that nodes automatically. Thus, you can have the scripts with keyboard shortcuts as the patterns are accessible via shortcuts.
      </li>
    </ol>
    <p>
      Every script is at evaluation time started with two predefined java objects coming from the map:
    </p>
    <ul>
      <li>
        node is the current node. It is a freemind.modes.MindMapNode. This node can be used to retrieve information about the contents, its children or its formatting. <i>Don't use the setter to change the node. Use the following instead:</i>
      </li>
      <li>
        c is the current controller. It is a freemind.modes.mindmapmode.MindMapController. This controller <b>should</b>&#xa0; &#xa0;&#xa0;&#xa0;be used to change information. For example, if you want to change the nodes text or if you want to add children. The methods that can be used are sumarized in freemind.modes.mindmapmode.actions.MindMapActions.
      </li>
    </ul>
    <p>
      There are two automatisms regarding the effect of a script:
    </p>
    <ol>
      <li>
        If a script starts with "=", the result of the script is taken to be the new nodes text. Example script1: =17+4. If executed, the node the script is associated to will be changed to 21.
      </li>
      <li>
        If a script starts with letters (digits and '_') only and then a "=" sign, like "sum=17+4", the result is taken to be a (possibly new) attribute named "sum" in this case with the content 21.
      </li>
    </ol>
    <p>
      For more examples consult our little scripting guide below or our web pages.
    </p>
    <p>
      A last word on security: before scripts is evaluated for the first time in FreeMind, the user is asked whether or not he allows it. The answer can be stored for every script but observe that a malicious script is able to perform every action on your computer that your users rights allow up to delete all files or send them to pirates.ru. This said, be careful and don't allow scripts when you don't know that the author is trusted. Finally, scripts are never evaluated automatically in FreeMind for these reasons. Thus, you can open a map without problems and have a look at the scripts it contains.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201506580407" ID="Freemind_Link_1055396713" MODIFIED="1381608219500" STYLE="fork" TEXT="Little FreeMind Scripting Guide (engl.)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      If your scripts want to change some map data (which they commonly want to) they should rely on the methods provided by the MindMapController c.
    </p>
    <p>
      These methods are summarized and partially documented in the class "MindMapActions":
    </p>
    <p>
      <a href="http://freemind.cvs.sourceforge.net/freemind/freemind/freemind/modes/mindmapmode/actions/MindMapActions.java?view=log&amp;pathrev=fm_060405_integration">http://freemind.cvs.sourceforge.net/freemind/freemind/freemind/modes/mindmapmode/actions/MindMapActions.java?view=log&amp;pathrev=fm_060405_integration</a>
    </p>
    <p>
      The listeners mentioned below (ie. NodeSelectionListener and NodeLifetimeListener) can be registered and found in the class "ModeController" (also c):
    </p>
    <p>
      <a href="http://freemind.cvs.sourceforge.net/freemind/freemind/freemind/modes/ModeController.java?view=log&amp;pathrev=fm_060405_integration">http://freemind.cvs.sourceforge.net/freemind/freemind/freemind/modes/ModeController.java?view=log&amp;pathrev=fm_060405_integration</a>
    </p>
    <p>
      Here we present some snippets of useful Groovy code that can be used as parts of your scripts. More scripts can be found on our web sites.
    </p>
    <ul>
      <li>
        Change the node text:<br/>=17+4<br/>(Explanation: if a script starts with "=", the result of the script is taken as the new nodes text.)
      </li>
      <li>
        Change an attributes value:<br/>attribute_name=17+4<br/>(Explanation: if a script starts with a name and then directly a "=" sign, its result is associated to this attribute which is created if not already present.)
      </li>
      <li>
        Read and change the nodes text:<br/>c.setNodeText(node, node.getText() + "_CHANGED");
      </li>
      <li>
        Read an attribute<br/>def value = node.getAttribute("key"); // value is of type String.<br/><br/>
      </li>
      <li>
        Create or change attributes: the following method checks whether or not an attribute with the same key exists and replaces it. Otherwise a new attribute is created and added.<br/>c.editAttribute(node, "key", "new value");<br/>
      </li>
      <li>
        Remove an attribute by name:<br/>c.editAttribute(node, "key", null);<br/>This method returns the former index of the attribute, or -1 if the key wasn't found.<br/>
      </li>
      <li>
        Traverse all children<br/>def it = node.childrenUnfolded();<br/>while(it.hasNext()) {<br/>def child = it.next();<br/>}
      </li>
      <li>
        Traverse all children and its children recursively. The following examples prints the content of every node including its childs<br/>

        <pre>def stack = new java.util.Stack();<br/>stack.push(node);<br/>while(stack.size()&gt;0) 
        {<br/>&#x9;&#x9;def current =stack.pop();<br/>&#x9;&#x9;print current.getShortText(c) + ", ";<br/>&#x9;&#x9;stack.addAll(current.getChildren());<br/>&#x9;}</pre>
        <br/>
        <br/>
        
      </li>
      <li>
        Real world example: nodes may have an attribute "work" that specifies the work needed for the specific work package (e.g. in days). This script computes the sum of all work packages such that each node gets an attribute "sum" containing the amount of work needed for all descendants. This script, if executed via Alt+F8, automatically applies to the root of the map. But, every time, you change the values, you have to reexecute this script.<br/><br/>

        <pre>def calcWork(child) {
&#x9;def sum = 0;
&#x9;def it = child.childrenUnfolded(); 
&#x9;while(it.hasNext()) { 
&#x9;&#x9;def child2 = it.next(); 
&#x9;&#x9;sum += calcWork(child2);
&#x9;&#x9;def w = child2.getAttribute("work");
&#x9;&#x9;if(w != null)
&#x9;&#x9;&#x9;sum += Integer.parseInt( w);
&#x9;}
&#x9;if(sum&gt;0)
&#x9;&#x9;c.editAttribute(child, "sum", (String) sum);
&#x9;return sum;
}

calcWork(c.getRootNode());</pre>
      </li>
      <li>
        A very advanced example: the last script is integrated into a listener that detects node changes, so the sums are always recreated when a node is changed. This script introduces a new element in scripting: the "cookies". It is a usual HashMap where scripts can store values that they need the next time, they are executed. For every map, there is a new cookie map, such that cookies are map local. Moreover, they are not stored persistently and are lost after termination of FreeMind or after closing a map. In this example, they serve as a static variable in which it is stored whether or not the script was already executed and which listener was used in order to deregister the old one first.<br/>

        <pre>class MyNodeListener implements freemind.modes.ModeController.NodeSelectionListener {
&#x9;freemind.modes.mindmapmode.MindMapController c;
        MyNodeListener(freemind.modes.mindmapmode.MindMapController con) {
&#x9;&#x9;this.c = con;
&#x9;&#x9;}

&#x9;&#x9;/** 
         * Sent, if a node is changed
         * */
        void onUpdateNodeHook(freemind.modes.MindMapNode node){&#x9;&#x9;
&#x9;&#x9;&#x9;calcWork(c.getRootNode());
&#x9;&#x9;};

        /** Is sent when a node is selected.
         */
        void onSelectHook(freemind.view.mindmapview.NodeView node){};
        /**
         * Is sent when a node is deselected.
         */
        void onDeselectHook(freemind.view.mindmapview.NodeView node){};

&#x9;&#x9;/**
&#x9;&#x9; * Is issued before a node is saved (eg. to save its notes, too, even if the notes is currently edited).
&#x9;&#x9; */
&#x9;&#x9;void onSaveNode(freemind.modes.MindMapNode node){};

def calcWork(child) {
&#x9;def sum = 0;
&#x9;def it = child.childrenUnfolded(); 
&#x9;while(it.hasNext()) { 
&#x9;&#x9;def child2 = it.next(); 
&#x9;&#x9;sum += calcWork(child2);
&#x9;&#x9;def w = child2.getAttribute("work");
&#x9;&#x9;if(w != null)
&#x9;&#x9;&#x9;sum += Integer.parseInt( w);
&#x9;}
&#x9;if(sum&gt;0)
&#x9;&#x9;c.editAttribute(child, "sum", (String) sum);
&#x9;return sum;
}

}

def cookieKey = "work_update_listener";
if(cookies.get(cookieKey) != null) {
&#x9;c.deregisterNodeSelectionListener(cookies.get(cookieKey));
}
def newListener = new MyNodeListener(c);
cookies.put(cookieKey, newListener);
c.registerNodeSelectionListener(newListener);
      </pre>
      </li>
      <li>
        A sorting example: Currently we provide a function that sorts all children by name, but if you want to sort them by their icons for example, you can use the following script (or change it, if you have different sorting criteria):<br/>

        <pre>import java.awt.datatransfer.Transferable;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;
import freemind.modes.MindMapNode;

&#x9;class IconComparator implements java.util.Comparator {
&#x9;&#x9;&#x9;int compare(java.lang.Object pArg0, java.lang.Object pArg1) {
&#x9;&#x9;&#x9;&#x9;if (pArg0 instanceof MindMapNode) {
&#x9;&#x9;&#x9;&#x9;&#x9;MindMapNode node1 = (MindMapNode) pArg0;
&#x9;&#x9;&#x9;&#x9;&#x9;if (pArg1 instanceof MindMapNode) {
&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;MindMapNode node2 = (MindMapNode) pArg1;
&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;String iconText1 = getIconText(node1);
&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;String iconText2 = getIconText(node2);
&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;//print "comparing" + iconText1 + " with " + iconText2 + "\n";
&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;return iconText1.compareToIgnoreCase(iconText2);
&#x9;&#x9;&#x9;&#x9;&#x9;}
&#x9;&#x9;&#x9;&#x9;}
&#x9;&#x9;&#x9;&#x9;return 0;
&#x9;&#x9;&#x9;}
&#x9;&#x9;def getIconText(MindMapNode n) {
&#x9;&#x9;&#x9;if(n.getIcons() == null || n.getIcons().size()==0) 
&#x9;&#x9;&#x9;&#x9;return "";
&#x9;&#x9;&#x9;def retString = "";
&#x9;&#x9;&#x9;def it = n.getIcons().iterator();
&#x9;&#x9;&#x9;while(it.hasNext()) {
&#x9;&#x9;&#x9;&#x9;retString +=it.next().getName()+", ";
&#x9;&#x9;&#x9;}
&#x9;&#x9;&#x9;return retString;
&#x9;&#x9;}
&#x9;}


&#x9;&#x9;// we want to sort the children of the node:
&#x9; &#x9;Vector children = new Vector();
&#x9;&#x9;// put in all children of the node
&#x9;&#x9;children.addAll(node.getChildren());
&#x9;&#x9;// sort them
&#x9;&#x9;java.util.Collections.sort(children, new IconComparator());
&#x9;&#x9;//print "The set has " + children.size() + " entries\n";
&#x9;&#x9;// now, as it is sorted. we cut the children
&#x9;&#x9;def it2 = children.iterator();
&#x9;&#x9;while (it2.hasNext()) {
&#x9;&#x9;&#x9;MindMapNode child = (MindMapNode) it2.next();
&#x9;&#x9;&#x9;Vector childList = new Vector();
&#x9;&#x9;&#x9;childList.add(child);
&#x9;&#x9;&#x9;Transferable cut = c.cut(childList);
&#x9;&#x9;&#x9;// paste directly again causes that the node is added as the last one.
&#x9;&#x9;&#x9;c.paste(cut, node);
&#x9;&#x9;}
&#x9;&#x9;c.select(c.getNodeView(node));</pre>
      </li>
      <li>
        A presentation script. Everytime you select a node, all other nodes are closed and this node is expanded by one. Just give it a try..<br/>

        <pre>class MyNodeListener implements freemind.modes.ModeController.NodeSelectionListener {
&#x9;freemind.modes.mindmapmode.MindMapController c;
        MyNodeListener(freemind.modes.mindmapmode.MindMapController con) {
&#x9;&#x9;this.c = con;
&#x9;&#x9;}

&#x9;&#x9;/** 
         * Sent, if a node is changed
         * */
        void onUpdateNodeHook(freemind.modes.MindMapNode node){&#x9;&#x9;
&#x9;&#x9;};

        /** Is sent when a node is selected.
         */
        void onSelectHook(freemind.view.mindmapview.NodeView node){
&#x9;&#x9;&#x9;if(c.getSelecteds().size()&gt;1)
&#x9;&#x9;&#x9;&#x9;return;
&#x9;&#x9;&#x9;// unfold node:
&#x9;&#x9;&#x9;c.setFolded(node.getModel(), false);
&#x9;&#x9;&#x9;// fold every child:
                def it2 = node.getModel().childrenUnfolded().iterator();
                while (it2.hasNext()) {
                        def child = it2.next();
&#x9;&#x9;&#x9;&#x9;  c.setFolded(child, true);
&#x9;&#x9;&#x9;}
&#x9;&#x9;&#x9;// close everything else:
&#x9;&#x9;&#x9;foldEverybody(node.getModel().getParent(),node.getModel());
&#x9;&#x9;};
        /**
         * Is sent when a node is deselected.
         */
        void onDeselectHook(freemind.view.mindmapview.NodeView node){};

&#x9;&#x9;/**
&#x9;&#x9; * Is issued before a node is saved (eg. to save its notes, too, even if the notes is currently edited).
&#x9;&#x9; */
&#x9;&#x9;void onSaveNode(freemind.modes.MindMapNode node){};
def foldEverybody(child, exception) {
&#x9;&#x9;if(child == null || child.isRoot())
&#x9;&#x9;&#x9;return;
        def it = child.childrenUnfolded();
        while(it.hasNext()) {
                def child2 = it.next();
&#x9;&#x9;&#x9;if(child2 != exception) {
&#x9;&#x9;&#x9;&#x9;c.setFolded(child2, true);
&#x9;&#x9;&#x9;}
        }
&#x9;if(!child.getParent().isRoot())
&#x9;&#x9;foldEverybody(child.getParent(), exception.getParent());
}


}

def cookieKey = "presentation_listener";
if(cookies.get(cookieKey) != null) {
&#x9;c.deregisterNodeSelectionListener(cookies.get(cookieKey));
}
def newListener = new MyNodeListener(c);
cookies.put(cookieKey, newListener);
c.registerNodeSelectionListener(newListener);</pre>
      </li>
    </ul>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1204696614656" ID="ID_491680673" MODIFIED="1381608223890" STYLE="fork" TEXT="How to install a script as a menu item (engl.)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Once, you've created or found some interesting scripts, you probably want to get a FreeMind menu item with an own shortcut to execute the script.
    </p>
    <p>
      To do this, save the script to a file and edit "ScriptingEngine.xml" inside the FreeMind script directory inside your installation.
    </p>
    <p>
      You'll find a template for a script action that is commented out (ie. surrounded by &lt;!-- ... --&gt;). Uncomment the template and fill out the following bold places:
    </p>
    <pre>      &lt;plugin_action
      name="<b>GroovyGroovy</b>"
      documentation="<b>this is my first installed groovy script.</b>"
      label="<b>plugins/GroovyScript1</b>"
      base="freemind.extensions.ModeControllerHookAdapter"
      class_name="plugins.script.ScriptingEngine"&gt;
      &lt;plugin_mode class_name="freemind.modes.mindmapmode"/&gt;
      &lt;plugin_menu location="<b>menu_bar/extras/first/scripting/groovy1</b>"/&gt;
      &lt;plugin_property name="ScriptLocation" value="<b>/home/foltin/test.groovy</b>"/&gt;
      &lt;/plugin_action&gt;
    </pre>
    <p>
      The most important change is the location of the script. Moreover, if you have several scripts you want to install, the labels and the menu_location must be unique.
    </p>
    <p>
      If you now restart FreeMind you get a new menu item (in this example in the "Extras" menu) that carries out your script. Observe, that the "node" variable points to the root node.
    </p>
    <p>
      If you want to have a keyboard short cut for the new script, you have to add the bold line into the entry in ScriptingEngine.xml like:
    </p>
    <pre>      &lt;plugin_action
      name="GroovyGroovy"
      documentation="this is my first installed groovy script."
      label="plugins/GroovyScript1"
      <b>key_stroke="control shift M" </b>
      base="freemind.extensions.ModeControllerHookAdapter"
      class_name="plugins.script.ScriptingEngine"&gt;
      &lt;plugin_mode class_name="freemind.modes.mindmapmode"/&gt;
      &lt;plugin_menu location="menu_bar/extras/first/scripting/groovy1"/&gt;
      &lt;plugin_property name="ScriptLocation" value="/home/foltin/test.groovy"/&gt;
      &lt;/plugin_action&gt;
    </pre>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1354041409110" FOLDED="true" ID="ID_1185769793" LINK="http://freemind.sourceforge.net/wiki/index.php/FreeMind_1.0.0:_The_New_Features" MODIFIED="1381609485199" POSITION="right" STYLE="fork" TEXT="Neue Funktionen in 1.0.0">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#407000" CREATED="1354041534617" ID="ID_485992024" MODIFIED="1381608262912" STYLE="fork" TEXT="Unterst&#xfc;tzung von Klons">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354041542053" FOLDED="true" ID="ID_76396394" MODIFIED="1381609056243" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Mindmaps k&#246;nnen freigegeben, und
    </p>
    <p>
      gleichzeitig von mehreren Personen ver&#228;ndert werden
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#407000" CREATED="1354049334525" ID="ID_1490791817" MODIFIED="1381608357295" STYLE="fork" TEXT="Die &#xc4;nderungen werden gegeneinander &quot;gelockt&quot;, d.h. es ist nicht m&#xf6;glich, dass Knoten vom einen gel&#xf6;scht, w&#xe4;hrend sie vom anderen bearbeitet werden">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049334525" ID="ID_787700684" MODIFIED="1381608393906" STYLE="fork" TEXT="Die &#xc4;nderungen werden &#xfc;ber den &quot;Master&quot; (der, der die Map freigibt) an die anderen Beteiligten weitergegeben">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049334525" ID="ID_338941685" MODIFIED="1381608433481" STYLE="fork" TEXT="Es gibt minimale Sicherheit: bevor man die Map sehen darf, mu&#xdf; man das richtige Passwort kennen. Allerdings gehen alle Nachrichten offen &#xfc;ber das Netzwerk!">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049334527" ID="ID_239293753" MODIFIED="1381608455694" STYLE="fork" TEXT="Kompression: zur Verbesserung der Effektivit&#xe4;t sind alle Nachrichten komprimiert">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049334528" ID="ID_1574037231" MODIFIED="1381608484862" STYLE="fork" TEXT="Die Verbindungseinstellungen werden in der Titelzeile angezeigt. Damit k&#xf6;nnen schnell neue Teilnehmer hinzugef&#xfc;gt werden.">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049334530" ID="ID_747999418" MODIFIED="1381608527940" STYLE="fork" TEXT="Auch die Teilnehmer selbst werden (mit 5 Sekunden Verz&#xf6;gerung) in der Titelzeile angezeigt.">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
</node>
<node COLOR="#407000" CREATED="1354041568484" ID="ID_1396819699" MODIFIED="1381608544068" STYLE="fork" TEXT="Knoten k&#xf6;nnen einen geographischen Ort haben!">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049151325" ID="ID_172673644" MODIFIED="1381608554817" STYLE="fork" TEXT="Dank Eike gibt es eine Rechtschreibpr&#xfc;fung">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354041626034" ID="ID_728564704" MODIFIED="1381608570127" STYLE="fork" TEXT="Alle ge&#xf6;ffneten Mindmaps werden beim n&#xe4;chsten Start wiederhergestellt">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049017472" FOLDED="true" ID="ID_497763930" MODIFIED="1381609056244" STYLE="fork" TEXT="QuickView Support f&#xfc;r Mac OSX">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#407000" CREATED="1381608578684" ID="ID_213337943" MODIFIED="1381609052649" STYLE="fork" TEXT="Bet&#xe4;tigen Sie auf einer Mindmap die Leertaste im Finder und Sie bekommen eine direkte Vorschau!">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
</node>
<node COLOR="#407000" CREATED="1381609026034" ID="ID_1770254561" MODIFIED="1381609051655" STYLE="fork" TEXT="Ein neuer Kreis erm&#xf6;glicht das Falten und Ausfalten per Maus">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049159148" FOLDED="true" ID="ID_1174384551" MODIFIED="1381609056246" STYLE="fork" TEXT="Kleine &#xc4;nderungen">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#407000" CREATED="1354041615600" ID="ID_1369145907" MODIFIED="1381608672737" STYLE="fork" TEXT="Steuerung + Q springt zu den letzten &#xc4;nderungen">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354048984649" ID="ID_1556364315" MODIFIED="1381608885698" STYLE="fork" TEXT="Es k&#xf6;nnen einzelne Zweige oder mehrere Knoten (in separate Dateien) nach PDF exportiert werden.">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049001883" ID="ID_86589059" MODIFIED="1381608699546" STYLE="fork" TEXT="Nach dem PDF-Export wird ein PDF-Viewer gestartet, wenn vorhanden">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049046101" ID="ID_1605954762" MODIFIED="1381608720158" STYLE="fork" TEXT="Dank Anantha k&#xf6;nnen Bilder nun direkt eingef&#xfc;gt werden!">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049051829" ID="ID_1932974359" MODIFIED="1381608766517" STYLE="fork" TEXT="Mindmaps werden auf Ver&#xe4;nderungen im darunterliegenden Dateisystem &#xfc;berwacht. Wenn die Mindmap von jemandem ge&#xe4;ndert wurde, erscheint eine Frage, ob sie neu geladen werden soll.">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049063363" ID="ID_455905559" MODIFIED="1381608793574" STYLE="fork" TEXT="Sofern gew&#xfc;nscht werden alle Mindmaps in einer einzigen Instanz von FreeMind ge&#xf6;ffnet (per Doppelklick auf die Datei).">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049078229" ID="ID_482054062" LINK="https://sourceforge.net/projects/freemind/forums/forum/320014/topic/4777695" MODIFIED="1381608810564" STYLE="fork" TEXT="Die Notiz-Tooltips k&#xf6;nnen abgeschaltet werden">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049083460" ID="ID_1907102486" MODIFIED="1381608829074" STYLE="fork" TEXT="Es gibt die M&#xf6;glichkeit, die Zwischenablage unformatiert einzuf&#xfc;gen.">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049098227" ID="ID_858423743" MODIFIED="1381608845347" STYLE="fork" TEXT="Der Hauptknoten kann zu einem anderen Knoten gewechselt werden">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049134360" ID="ID_81088554" LINK="https://sourceforge.net/tracker/?func=detail&amp;atid=307118&amp;aid=3442896&amp;group_id=7118" MODIFIED="1381608862174" STYLE="fork" TEXT="Es gibt einen neuen Filter f&#xfc;r Knoten, die kein Icon enthalten">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
<node COLOR="#407000" CREATED="1354049311677" ID="ID_1888591328" MODIFIED="1381608915509" STYLE="fork" TEXT="Http-Proxies k&#xf6;nnen in den Einstellungen eingegeben werden (f&#xfc;r die Landkarten)">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
</node>
</node>
</node>
</node>
</map>
